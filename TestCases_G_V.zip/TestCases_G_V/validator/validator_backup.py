

# 18-feb-code this is working

# import json
# import numpy as np
# from pathlib import Path
# from sentence_transformers import SentenceTransformer, CrossEncoder
# from sklearn.metrics.pairwise import cosine_similarity
# from scipy.special import softmax

# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
# )

# # Generator is imported lazily to avoid circular issues
# # (only used in integrated feedback loop)


# # -----------------------------
# # Models (loaded once)
# # -----------------------------
# EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
# NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

# embedder = SentenceTransformer(EMBEDDING_MODEL)
# nli_model = CrossEncoder(NLI_MODEL)


# # ================================
# # Load JSON requirements
# # ================================
# def load_requirements(json_path: Path):
#     with json_path.open("r", encoding="utf-8") as f:
#         data = json.load(f)

#     requirements = []
#     for section, items in data.items():
#         for item in items:
#             text = item.strip()
#             if len(text) < 10:
#                 continue
#             requirements.append({
#                 "text": text,
#                 "category": section
#             })
#     return requirements


# # ================================
# # Load test cases (TXT)
# # ================================
# def load_testcases(txt_path: Path):
#     with txt_path.open("r", encoding="utf-8") as f:
#         return [line.strip() for line in f if line.strip()]


# # ================================
# # Core Validator (PUBLIC API)
# # ================================
# def validate_testcases(
#     requirement_file: Path,
#     testcase_file: Path,
# ):
#     print("Loading requirements...")
#     requirements = load_requirements(requirement_file)
#     req_texts = [r["text"] for r in requirements]

#     print("Loading test cases...")
#     testcases = load_testcases(testcase_file)

#     if not requirements or not testcases:
#         raise ValueError("Empty requirements or test cases provided.")

#     print("Generating embeddings...")
#     req_emb = embedder.encode(
#         req_texts,
#         convert_to_numpy=True,
#         normalize_embeddings=True
#     )
#     tc_emb = embedder.encode(
#         testcases,
#         convert_to_numpy=True,
#         normalize_embeddings=True
#     )

#     sim_matrix = cosine_similarity(req_emb, tc_emb)

#     coverage = {}
#     missing = []
#     accuracy_scores = []

#     print("Validating coverage...")
#     for i, req in enumerate(requirements):
#         semantic_candidates = []

#         # -------- Semantic filtering --------
#         for j, tc in enumerate(testcases):
#             if sim_matrix[i][j] >= SEMANTIC_THRESHOLD:
#                 semantic_candidates.append(tc)

#         matches = []

#         # -------- NLI validation --------
#         for tc in semantic_candidates:
#             logits = nli_model.predict([(tc, req["text"])])[0]
#             probs = softmax(logits)

#             entailment_score = float(probs[2])  # entailment
#             if entailment_score >= NLI_THRESHOLD:
#                 matches.append({
#                     "testcase": tc,
#                     "entailment_score": round(entailment_score, 3)
#                 })
#                 accuracy_scores.append(entailment_score)

#         if matches:
#             coverage[req["text"]] = {
#                 "category": req["category"],
#                 "matches": matches
#             }
#         else:
#             missing.append({
#                 "requirement": req["text"],
#                 "category": req["category"]
#             })

#     total = len(requirements)
#     covered = len(coverage)

#     completeness = (covered / total) * 100 if total else 0
#     accuracy = (np.mean(accuracy_scores) * 100) if accuracy_scores else 0

#     print("\n========== VALIDATION RESULT ==========")
#     print(f"Total Requirements: {total}")
#     print(f"Covered Requirements: {covered}")
#     print(f"Missing Requirements: {len(missing)}")
#     print(f"Completeness Percentage: {round(completeness, 2)}%")
#     print(f"Accuracy Percentage: {round(accuracy, 2)}%")

#     if missing:
#         print("\nMissing Requirements:")
#         for req in missing:
#             print(f"- {req['requirement']} (Category: {req['category']})")

#     # FEEDBACK LOOP (ONLY IN INTEGRATED MODE)
#     # if (
#     #     MODE == "INTEGRATED"
#     #     and completeness < COMPLETENESS_THRESHOLD
#     #     and accuracy >= ACCURACY_THRESHOLD
#     #     and missing
#     # ):
#     #     print("\nCompleteness below threshold → triggering generator...")

#     #     from generator.generator import run_generator  

#     #     missing_dict = {}
#     #     for m in missing:
#     #         missing_dict.setdefault(m["category"], []).append(m["requirement"])

#     #     missing_file = requirement_file.parent / "missing_requirements.json"
#     #     with missing_file.open("w", encoding="utf-8") as f:
#     #         json.dump(missing_dict, f, indent=2, ensure_ascii=False)

#     #     run_generator(
#     #         master_requirement_file=requirement_file,
#     #         new_requirement_file=missing_file,
#     #         output_testcase_file=testcase_file,
#     #         hash_file=requirement_file.parent / "requirement_hash.txt"
#     #     )

#     #     print("Feedback loop completed: missing test cases generated.")

#     # return {
#     #     "coverage": coverage,
#     #     "missing": missing,
#     #     "completeness": round(completeness, 2),
#     #     "accuracy": round(accuracy, 2),
#     # }
#     return coverage, missing, completeness, accuracy 













# import json
# import numpy as np
# import re
# from pathlib import Path
# from sentence_transformers import SentenceTransformer, CrossEncoder
# from sklearn.feature_extraction.text import TfidfVectorizer
# from sklearn.metrics.pairwise import cosine_similarity
# from scipy.special import softmax
# import nltk
# from nltk.stem import WordNetLemmatizer
# from concurrent.futures import ThreadPoolExecutor
# import torch

# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
# )

# nltk.download('punkt', quiet=True)
# nltk.download('wordnet', quiet=True)
# lemmatizer = WordNetLemmatizer()

# # -----------------------------
# # Upgraded Models (better accuracy)
# # -----------------------------
# EMBEDDING_MODEL = "sentence-transformers/paraphrase-mpnet-base-v2"
# NLI_MODEL = "microsoft/deberta-large-mnli"

# # Enable FP16 for speed
# device = "cuda" if torch.cuda.is_available() else "cpu"
# embedder = SentenceTransformer(EMBEDDING_MODEL, device=device)
# if device == "cuda":
#     embedder = embedder.half()
# nli_model = CrossEncoder(NLI_MODEL, device=device)
# if device == "cuda":
#     nli_model = nli_model.half()

# # Pre-trained TF-IDF for keywords
# tfidf = TfidfVectorizer(max_features=5000, stop_words='english')

# def preprocess_text(text):
#     """Clean + lemmatize (spaCy-free)"""
#     text = re.sub(r'[^\w\s]', ' ', text.lower())
#     words = nltk.word_tokenize(text)
#     lemmas = [lemmatizer.lemmatize(word) for word in words if word.isalpha()]
#     return ' '.join(lemmas)

# def keyword_overlap_score(req_text, tc_text):
#     """Simple keyword boost"""
#     req_words = set(req_text.lower().split())
#     tc_words = set(tc_text.lower().split())
#     common = req_words.intersection(tc_words)
#     return len(common) / max(len(req_words), 1)

# # ================================
# # DYNAMIC SYNONYM EXTRACTION (NEW)
# # ================================
# def extract_dynamic_synonyms(all_reqs, all_tests):
#     """Auto-discover synonyms from requirements + testcases - 100% DYNAMIC"""
#     synonyms = {}
    
#     # Universal patterns that work across ANY SSD
#     key_patterns = [
#         r'\b(nbl|system|application|app)\b',        
#         r'\b(alert|show|display|trigger|message|warn)\b',  
#         r'\b(disable|disabled|disabling|block|suppress|prevent)\b',  
#         r'\b(button|action|print|scan|upload|transmit|reset)\b',     
#         r'\b(above|over|greater)\s+\d+\b',                              
#         r'\b(less|under|below)\s+\d+\b',                                
#         r'\b(driver|user|applicant)\b',                                 
#     ]
    
#     all_text = ' '.join(all_reqs + all_tests).lower()
#     matches = {}
    
#     for pattern in key_patterns:
#         found = re.findall(pattern, all_text)
#         if len(set(found)) > 1:
#             matches[pattern] = list(set(found))
    
#     for pattern, terms in matches.items():
#         if len(terms) > 1:
#             base_term = terms[0]
#             synonyms[base_term] = terms[1:]
    
#     return synonyms

# # ================================
# # Load JSON requirements
# # ================================
# def load_requirements(json_path: Path):
#     with json_path.open("r", encoding="utf-8") as f:
#         data = json.load(f)
#     requirements = []
#     for section, items in data.items():
#         for item in items:
#             text = item.strip()
#             if len(text) < 10:
#                 continue
#             requirements.append({
#                 "text": text,
#                 "preprocessed": preprocess_text(text),
#                 "category": section
#             })
#     return requirements

# # ================================
# # Load test cases (TXT)
# # ================================
# def load_testcases(txt_path: Path):
#     with txt_path.open("r", encoding="utf-8") as f:
#         return [line.strip() for line in f if line.strip()]

# # ================================
# # Single req validation (SIMPLIFIED - NO PARALLEL BUGS)
# # ================================
# def validate_single_req(req, testcases, req_emb, tc_emb, sim_matrix, tfidf_matrix, req_texts, all_reqs, all_tests):
#     """100% DYNAMIC - auto-learns synonyms from data (NON-PARALLEL SAFE)"""
#     i = req_texts.index(req["text"])
    
#     # Extract DYNAMIC synonyms from CURRENT dataset
#     DYNAMIC_SYNONYMS = extract_dynamic_synonyms(all_reqs, all_tests)
    
#     # FIXED: Safe top-K selection
#     num_tests = len(testcases)
#     top_k = min(10, num_tests)
#     top_indices = np.argpartition(sim_matrix[i], -top_k)[-top_k:] if num_tests > 0 else []
    
#     candidates = []
    
#     for j in top_indices:
#         if sim_matrix[i][j] >= 0.18:
#             tc = testcases[j]
#             sem_score = sim_matrix[i][j]
#             kw_score = keyword_overlap_score(req["text"], tc)
            
#             # DYNAMIC synonym boost
#             synonym_boost = 0
#             req_lower = req["text"].lower()
#             tc_lower = tc.lower()
            
#             for req_term, alt_terms in DYNAMIC_SYNONYMS.items():
#                 if req_term in req_lower:
#                     for alt_term in alt_terms:
#                         if alt_term in tc_lower:
#                             synonym_boost += 0.12
#                             break
            
#             # Domain term boost
#             domain_boost = 0
#             req_nouns = set(re.findall(r'\b\w+(?:ed|s|ing)?\b', req_lower))
#             tc_nouns = set(re.findall(r'\b\w+(?:ed|s|ing)?\b', tc_lower))
#             common_nouns = req_nouns.intersection(tc_nouns)
#             domain_boost = len(common_nouns) * 0.08
            
#             hybrid_score = 0.55 * sem_score + 0.25 * kw_score + synonym_boost + domain_boost
#             candidates.append((tc, hybrid_score))
    
#     candidates.sort(key=lambda x: x[1], reverse=True)
#     matches = []
    
#     # Progressive NLI fallback
#     pairs = [(tc[0], req["text"]) for tc in candidates[:10]]
#     if pairs:
#         try:
#             logits = nli_model.predict(pairs, batch_size=16, show_progress_bar=False)
#             for idx, (tc, hybrid_score) in enumerate(candidates[:10]):
#                 probs = softmax(logits[idx])
#                 entailment = probs[2]
                
#                 if entailment >= 0.22:
#                     matches.append({
#                         "testcase": tc,
#                         "entailment_score": round(float(entailment), 3),
#                         "hybrid_score": round(float(hybrid_score), 3)
#                     })
#                 elif hybrid_score >= 0.45:
#                     matches.append({
#                         "testcase": tc,
#                         "entailment_score": 0.0,
#                         "hybrid_score": round(float(hybrid_score), 3)
#                     })
#         except Exception:
#             for tc, hybrid_score in candidates[:3]:
#                 if hybrid_score >= 0.42:
#                     matches.append({
#                         "testcase": tc,
#                         "entailment_score": 0.0,
#                         "hybrid_score": round(float(hybrid_score), 3)
#                     })
    
#     return req, matches

# # ================================
# # Core Validator (FIXED PARALLELISM)
# # ================================
# def validate_testcases(requirement_file: Path, testcase_file: Path):
#     print("Loading requirements...")
#     requirements = load_requirements(requirement_file)
#     req_texts = [r["text"] for r in requirements]
#     req_preproc = [r["preprocessed"] for r in requirements]
#     all_reqs = req_texts

#     print("Loading test cases...")
#     testcases = load_testcases(testcase_file)
#     all_tests = testcases

#     if not requirements or not testcases:
#         raise ValueError("Empty requirements or test cases provided.")

#     print("Generating embeddings...")
#     req_emb = embedder.encode(req_texts, convert_to_numpy=True, normalize_embeddings=True)
#     tc_emb = embedder.encode(testcases, convert_to_numpy=True, normalize_embeddings=True)

#     print("Computing similarity matrices...")
#     sim_matrix = cosine_similarity(req_emb, tc_emb)
    
#     tfidf_matrix = cosine_similarity(
#         tfidf.fit_transform(req_preproc).toarray(), 
#         tfidf.transform([preprocess_text(tc) for tc in testcases]).toarray()
#     )

#     coverage = {}
#     missing = []
#     accuracy_scores = []

#     print("Extracting dynamic synonyms from data...")
#     print("Validating coverage...")

#     # FIXED: Sequential processing (no parallel bugs)
#     for req in requirements:
#         req, matches = validate_single_req(
#             req, testcases, req_emb, tc_emb, sim_matrix, tfidf_matrix, 
#             req_texts, all_reqs, all_tests
#         )
        
#         if matches:
#             coverage[req["text"]] = {
#                 "category": req["category"],
#                 "matches": matches
#             }
#             accuracy_scores.extend([m["entailment_score"] for m in matches if m["entailment_score"] > 0])
#         else:
#             missing.append({
#                 "requirement": req["text"],
#                 "category": req["category"]
#             })

#     total = len(requirements)
#     covered = len(coverage)
#     completeness = (covered / total) * 100 if total else 0
#     accuracy = (np.mean(accuracy_scores) * 100) if accuracy_scores else 0

#     print("\n========== VALIDATION RESULT ==========")
#     print(f"Total Requirements: {total}")
#     print(f"Covered Requirements: {covered}")
#     print(f"Missing Requirements: {len(missing)}")
#     print(f"Completeness Percentage: {round(completeness, 2)}%")
#     print(f"Accuracy Percentage: {round(accuracy, 2)}%")

#     if missing:
#         print("\nMissing Requirements:")
#         for req in missing:
#             print(f"- {req['requirement'][:100]}... (Category: {req['category']})")

#     covered_tests = set()
#     for matches_list in coverage.values():
#         for m in matches_list["matches"]:
#             covered_tests.add(m["testcase"])
#     orphans = [tc for tc in testcases if tc not in covered_tests]
#     print(f"\nOrphan Test Cases: {len(orphans)}")

#     return coverage, missing, completeness, accuracy, orphans





















#Priotizing Testcases code


# import json
# import numpy as np
# import pandas as pd
# from pathlib import Path
# from sentence_transformers import SentenceTransformer, CrossEncoder
# from sklearn.metrics.pairwise import cosine_similarity
# from scipy.special import softmax
# import openpyxl
# from openpyxl.styles import Font, PatternFill, Alignment
# import re
# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
# )

# # Models (UNCHANGED)
# EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
# NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

# embedder = SentenceTransformer(EMBEDDING_MODEL)
# nli_model = CrossEncoder(NLI_MODEL)

# # ================================
# # Load JSON requirements (UNCHANGED)
# # ================================
# def load_requirements(json_path: Path):
#     with json_path.open("r", encoding="utf-8") as f:
#         data = json.load(f)

#     requirements = []
#     for section, items in data.items():
#         for item in items:
#             text = item.strip()
#             if len(text) < 10:
#                 continue
#             requirements.append({
#                 "text": text,
#                 "category": section
#             })
#     return requirements

# # ================================
# # 🆕 FIXED: Parse YOUR EXACT testcases.txt format
# # ================================
# def load_testcases(txt_path: Path):
#     """🔧 FIXED: Parse your exact testcases.txt format"""
#     print(f"📖 Reading test cases from: {txt_path}")
    
#     with txt_path.open("r", encoding="utf-8") as f:
#         content = f.read()
    
#     testcases = []
#     sections = {"positive": [], "negative": [], "boundary": []}
    
#     # Split by main sections
#     content = re.split(r'(Positive:|Negative:|Boundary:)', content, flags=re.IGNORECASE)
    
#     current_section = None
#     for i, part in enumerate(content):
#         part = part.strip()
        
#         # Detect section headers
#         if 'positive' in part.lower():
#             current_section = 'positive'
#         elif 'negative' in part.lower():
#             current_section = 'negative' 
#         elif 'boundary' in part.lower():
#             current_section = 'boundary'
        
#         # Extract test cases (lines starting with "Verify")
#         if current_section and i > 0:
#             lines = part.split('\n')
#             for line in lines:
#                 line = line.strip()
#                 if line and len(line) > 10 and ('verify' in line.lower() or 'validate' in line.lower()):
#                     testcases.append({
#                         "text": line,
#                         "distribution": current_section
#                     })
#                     sections[current_section].append(line)
    
#     print(f"✅ Found {len(testcases)} test cases:")
#     print(f"   Positive: {len(sections['positive'])}")
#     print(f"   Negative: {len(sections['negative'])}") 
#     print(f"   Boundary: {len(sections['boundary'])}")
    
#     return testcases, sections

# # ================================
# # PRIORITIZATION (UNCHANGED)
# # ================================
# def prioritize_testcases_from_scores(sim_matrix: np.ndarray, testcases: list, requirements: list):
#     testcase_scores = []
    
#     for j, tc in enumerate(testcases):
#         avg_similarity = np.mean(sim_matrix[:, j])
#         covered_reqs = sum(1 for i in range(len(requirements)) if sim_matrix[i][j] >= SEMANTIC_THRESHOLD)
#         coverage_ratio = min(covered_reqs / len(requirements), 1.0)
        
#         best_entailment = 0.0
#         for i, req_text in enumerate([r["text"] for r in requirements]):
#             try:
#                 logits = nli_model.predict([(tc['text'], req_text)])[0]
#                 probs = softmax(logits)
#                 best_entailment = max(best_entailment, probs[2])
#             except:
#                 continue
        
#         risk_keywords = ['security', 'login', 'payment', 'error', 'auth', 'critical', 'fee', '966']
#         risk_score = 0.9 if any(kw in tc['text'].lower() for kw in risk_keywords) else 0.5
        
#         priority_score = (
#             avg_similarity * 0.4 +
#             coverage_ratio * 0.3 +
#             best_entailment * 0.2 +
#             risk_score * 0.1
#         )
        
#         testcase_scores.append({
#             'id': len(testcase_scores) + 101,
#             'testcase': tc['text'],
#             'distribution': tc['distribution'],
#             'priority_score': priority_score,
#             'priority_rank': 'high' if priority_score > 0.7 else 'medium' if priority_score > 0.4 else 'low'
#         })
    
#     return sorted(testcase_scores, key=lambda x: x['priority_score'], reverse=True)

# # ================================
# # 🆕 YOUR EXACT XLSX FORMAT
# # ================================
# def export_prioritized_xlsx(prioritized_testcases, output_dir):
#     OUTPUT_PATH = Path(output_dir)
#     OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    
#     # YOUR EXACT FORMAT
#     excel_data = []
#     for tc in prioritized_testcases:
#         excel_data.append({
#             'id': tc['id'],
#             'userstory': tc['testcase'],
#             'testcases distribution (positive,negative,boundary)': tc['priority_rank']
#         })
    
#     df = pd.DataFrame(excel_data)
#     xlsx_path = OUTPUT_PATH / "prioritized_testcases.xlsx"
    
#     with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
#         df.to_excel(writer, sheet_name='TestCases', index=False)
        
#         worksheet = writer.sheets['TestCases']
        
#         # Header formatting
#         header_font = Font(bold=True, color="FFFFFF")
#         header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
#         for cell in worksheet[1]:
#             cell.font = header_font
#             cell.fill = header_fill
#             cell.alignment = Alignment(horizontal="center")
        
#         # Color code priority
#         for row in range(2, len(df)+2):
#             priority_cell = worksheet.cell(row=row, column=3)
#             priority = df.iloc[row-2]['testcases distribution (positive,negative,boundary)']
            
#             if priority == 'high':
#                 priority_cell.fill = PatternFill(start_color="FFEBEE", end_color="FFEBEE", fill_type="solid")
#             elif priority == 'medium':
#                 priority_cell.fill = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid")
#             else:
#                 priority_cell.fill = PatternFill(start_color="E8F5E8", end_color="E8F5E8", fill_type="solid")
    
#     print(f"✅ XLSX SAVED: {xlsx_path}")
#     return xlsx_path

# # ================================
# # MAIN VALIDATOR (FIXED)
# # ================================
# def validate_testcases(
#     requirement_file: Path,
#     testcase_file: Path,
#     output_dir: str = r"C:\Users\Divya\Desktop\TestCases_G_V\data\output\testcases"
# ):
#     print("🔍 VALIDATOR + PRIORITIZER STARTED")
    
#     # Load requirements
#     requirements = load_requirements(requirement_file)
#     if not requirements:
#         raise ValueError("No requirements found!")
    
#     # 🆕 FIXED: Load test cases properly
#     testcases_data, sections = load_testcases(testcase_file)
#     testcases = [tc['text'] for tc in testcases_data]
    
#     if not testcases:
#         raise ValueError("No test cases found! Check testcases.txt format.")
    
#     print(f"📊 Loaded: {len(requirements)} requirements, {len(testcases)} test cases")
    
#     # Generate similarity matrix (FIXED empty array issue)
#     req_emb = embedder.encode([r["text"] for r in requirements], convert_to_numpy=True, normalize_embeddings=True)
#     tc_emb = embedder.encode(testcases, convert_to_numpy=True, normalize_embeddings=True)
    
#     # Ensure 2D arrays
#     req_emb = req_emb.reshape(1, -1) if req_emb.ndim == 1 else req_emb
#     tc_emb = tc_emb.reshape(1, -1) if tc_emb.ndim == 1 else tc_emb
    
#     sim_matrix = cosine_similarity(req_emb, tc_emb)
    
#     # PRIORITIZE ALL TEST CASES
#     prioritized_testcases = prioritize_testcases_from_scores(sim_matrix, testcases_data, requirements)
    
#     # EXPORT YOUR EXACT XLSX FORMAT
#     xlsx_path = export_prioritized_xlsx(prioritized_testcases, output_dir)
    
#     # Original validation (coverage calculation)
#     coverage = {}
#     missing = []
#     accuracy_scores = []
    
#     for i, req in enumerate(requirements):
#         semantic_candidates = [testcases[j] for j in range(len(testcases)) if sim_matrix[i][j] >= SEMANTIC_THRESHOLD]
        
#         matches = []
#         for tc in semantic_candidates:
#             logits = nli_model.predict([(tc, req["text"])])[0]
#             probs = softmax(logits)
#             entailment_score = float(probs[2])
#             if entailment_score >= NLI_THRESHOLD:
#                 matches.append({"testcase": tc, "entailment_score": round(entailment_score, 3)})
#                 accuracy_scores.append(entailment_score)
        
#         if matches:
#             coverage[req["text"]] = {"category": req["category"], "matches": matches}
#         else:
#             missing.append({"requirement": req["text"], "category": req["category"]})
    
#     # Results
#     total = len(requirements)
#     covered = len(coverage)
#     completeness = (covered / total) * 100 if total else 0
#     accuracy = (np.mean(accuracy_scores) * 100) if accuracy_scores else 0
    
#     print("\n" + "="*80)
#     print("🏆 COMPLETE!")
#     print(f"📈 Coverage: {covered}/{total} ({completeness:.1f}%)")
#     print(f"📊 Accuracy: {accuracy:.1f}%")
#     print(f"📄 XLSX: {xlsx_path}")
    
#     high_count = len([tc for tc in prioritized_testcases if tc['priority_rank'] == 'high'])
#     print(f"🔴 HIGH Priority: {high_count}/{len(prioritized_testcases)}")
    
#     return coverage, missing, completeness, accuracy, prioritized_testcases, xlsx_path

# if __name__ == "__main__":
#     validate_testcases(
#         requirement_file=Path("high_accuracy_requirements.json"),
#         testcase_file=Path("testcases.txt"),
#         output_dir=r"C:/Users/Divya/Desktop/TestCases_G_V/data/output/testcases"
#     )









#last updated code

# import json
# import numpy as np
# import pandas as pd
# from pathlib import Path
# from sentence_transformers import SentenceTransformer, CrossEncoder
# from sklearn.metrics.pairwise import cosine_similarity
# from scipy.special import softmax
# import openpyxl
# from openpyxl.styles import Font, PatternFill, Alignment
# import re
# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
# )

# # Models
# EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
# NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

# embedder = SentenceTransformer(EMBEDDING_MODEL)
# nli_model = CrossEncoder(NLI_MODEL)

# # ================================
# # Load JSON requirements
# # ================================
# def load_requirements(json_path: Path):
#     with json_path.open("r", encoding="utf-8") as f:
#         data = json.load(f)

#     requirements = []
#     for section, items in data.items():
#         for item in items:
#             text = item.strip()
#             if len(text) < 10:
#                 continue
#             requirements.append({
#                 "text": text,
#                 "category": section
#             })
#     return requirements

# # ================================
# # 🆕 FIXED: Parse YOUR exact testcases.txt - NO BRACKETS IN USERSTORY
# # ================================
# def load_testcases(txt_path: Path):
#     print(f"📖 Reading test cases from: {txt_path}")
    
#     with txt_path.open("r", encoding="utf-8") as f:
#         content = f.read()
    
#     testcases = []
    
#     # Split by sections exactly matching your format
#     sections_raw = re.split(r'(?=^(Positive|Negative|Boundary):)', content, flags=re.MULTILINE | re.IGNORECASE)
    
#     current_section = None
#     section_mapping = {'Positive': 'positive', 'Negative': 'negative', 'Boundary': 'boundary'}
    
#     for section_part in sections_raw:
#         section_part = section_part.strip()
        
#         # Detect section
#         for sec_name in section_mapping:
#             if section_part.startswith(f"{sec_name}:"):
#                 current_section = section_mapping[sec_name]
#                 section_part = section_part.replace(f"{sec_name}:", "").strip()
#                 break
        
#         # Extract test cases
#         if current_section:
#             lines = section_part.split('\n')
#             for line in lines:
#                 line = line.strip()
#                 if (line and len(line) > 20 and 
#                     ('verify' in line.lower() or 'validate' in line.lower() or 'ensure' in line.lower())):
                    
#                     testcases.append({
#                         "text": line,
#                         "full_text": line,  # 🆕 CLEAN - NO BRACKETS IN USERSTORY
#                         "distribution": current_section  # Type for last column
#                     })
    
#     print(f"✅ Found {len(testcases)} test cases")
#     return testcases

# # ================================
# # PRIORITIZATION USING VALIDATOR SCORES
# # ================================
# def prioritize_testcases_from_scores(sim_matrix: np.ndarray, testcases: list, requirements: list):
#     testcase_scores = []
    
#     for j, tc_data in enumerate(testcases):
#         tc_text = tc_data['text']
        
#         # 1. Average similarity (35%)
#         avg_similarity = np.mean(sim_matrix[:, j])
        
#         # 2. Coverage ratio (25%)
#         covered_reqs = sum(1 for i in range(len(requirements)) if sim_matrix[i][j] >= SEMANTIC_THRESHOLD)
#         coverage_ratio = min(covered_reqs / len(requirements), 1.0)
        
#         # 3. Best entailment score (20%)
#         best_entailment = 0.0
#         for i, req_text in enumerate([r["text"] for r in requirements]):
#             try:
#                 logits = nli_model.predict([(tc_text, req_text)])[0]
#                 probs = softmax(logits)
#                 best_entailment = max(best_entailment, probs[2])
#             except:
#                 continue
        
#         # 4. Risk score (10%)
#         risk_keywords = ['security', 'login', 'payment', 'error', 'auth', 'critical', 'fee', '966', 'public sector']
#         risk_score = 0.9 if any(kw in tc_text.lower() for kw in risk_keywords) else 0.5
        
#         # 5. Scenario bonus (10%)
#         scenario_bonus = 1.0 if tc_data['distribution'] == 'negative' else 0.8 if tc_data['distribution'] == 'boundary' else 0.7
        
#         priority_score = (
#             avg_similarity * 0.35 +
#             coverage_ratio * 0.25 +
#             best_entailment * 0.20 +
#             risk_score * 0.10 +
#             scenario_bonus * 0.10
#         )
        
#         priority_rank = 'high' if priority_score > 0.7 else 'medium' if priority_score > 0.45 else 'low'
        
#         testcase_scores.append({
#             'id': None,  # Sequential numbering later
#             'userstory': tc_data['full_text'],  # 🆕 CLEAN USERSTORY (NO BRACKETS)
#             'priority': priority_rank,  # high/medium/low
#             'testcases distribution': tc_data['distribution'],  # ACTUAL: positive/negative/boundary
#             'priority_score': priority_score,
#             'distribution': tc_data['distribution']  # For internal use
#         })
    
#     # Sort by priority (HIGH FIRST)
#     prioritized = sorted(testcase_scores, key=lambda x: x['priority_score'], reverse=True)
    
#     # 🆕 SEQUENTIAL IDS STARTING FROM 101
#     for i, tc in enumerate(prioritized, 101):
#         tc['id'] = i
    
#     return prioritized

# # ================================
# # 🆕 4 COLUMNS PERFECT FORMAT
# # ================================
# def export_prioritized_xlsx(prioritized_testcases, output_dir):
#     OUTPUT_PATH = Path(output_dir)
#     OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    
#     # 🆕 YOUR EXACT 4-COLUMN FORMAT
#     excel_data = []
#     for tc in prioritized_testcases:
#         excel_data.append({
#             'id': tc['id'],
#             'userstory': tc['userstory'],  # CLEAN Verify that...
#             'priority': tc['priority'],  # high/medium/low
#             'testcases distribution': tc['testcases distribution']  # positive/negative/boundary
#         })
    
#     df = pd.DataFrame(excel_data)
#     xlsx_path = OUTPUT_PATH / "testcases.xlsx"
    
#     with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
#         df.to_excel(writer, sheet_name='TestCases', index=False)
        
#         worksheet = writer.sheets['TestCases']
        
#         # Headers
#         headers = ['id', 'userstory', 'priority', 'testcases distribution']
#         header_font = Font(bold=True, color="FFFFFF", size=12)
#         header_fill = PatternFill(start_color="2E75B6", end_color="2E75B6", fill_type="solid")
        
#         for col_num, header in enumerate(headers, 1):
#             cell = worksheet.cell(row=1, column=col_num)
#             cell.value = header
#             cell.font = header_font
#             cell.fill = header_fill
#             cell.alignment = Alignment(horizontal="center", vertical="center")
        
#         # Auto-adjust column widths
#         for column in worksheet.columns:
#             max_length = 0
#             column_letter = column[0].column_letter
#             for cell in column:
#                 try:
#                     if len(str(cell.value)) > max_length:
#                         max_length = len(str(cell.value))
#                 except:
#                     pass
#             adjusted_width = min(max_length + 2, 80)
#             worksheet.column_dimensions[column_letter].width = adjusted_width
        
#         # Color code PRIORITY column (Column C)
#         for row in range(2, len(df)+2):
#             priority_cell = worksheet.cell(row=row, column=3)  # Priority column
#             dist_cell = worksheet.cell(row=row, column=4)      # Distribution column
            
#             priority = df.iloc[row-2]['priority']
            
#             # Priority colors (Column C)
#             if priority == 'high':
#                 priority_cell.fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
#                 priority_cell.font = Font(color="D32F2F", bold=True)
#             elif priority == 'medium':
#                 priority_cell.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
#                 priority_cell.font = Font(color="F57C00", bold=True)
#             else:  # low
#                 priority_cell.fill = PatternFill(start_color="E8F5E8", end_color="E8F5E8", fill_type="solid")
#                 priority_cell.font = Font(color="2E7D32", bold=True)
            
#             # Distribution colors (Column D)
#             dist_value = df.iloc[row-2]['testcases distribution']
#             if dist_value == 'positive':
#                 dist_cell.fill = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")
#                 dist_cell.font = Font(color="1976D2", bold=True)
#             elif dist_value == 'negative':
#                 dist_cell.fill = PatternFill(start_color="FFEBEE", end_color="FFEBEE", fill_type="solid")
#                 dist_cell.font = Font(color="D32F2F", bold=True)
#             else:  # boundary
#                 dist_cell.fill = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid")
#                 dist_cell.font = Font(color="F57C00", bold=True)
    
#     print(f"✅ XLSX EXPORTED: {xlsx_path}")
#     return xlsx_path

# # ================================
# # MAIN VALIDATOR
# # ================================
# def validate_testcases(
#     requirement_file: Path,
#     testcase_file: Path,
#     output_dir: str = r"C:/Users/Divya/Desktop/TestCases_G_V/data/output/testcases"
# ):
#     print("🔍 VALIDATOR + PRIORITIZER STARTED")
    
#     requirements = load_requirements(requirement_file)
#     if not requirements:
#         print("❌ No requirements found!")
#         return None, [], 0, 0, [], None
    
#     testcases_data = load_testcases(testcase_file)
#     if not testcases_data:
#         print("❌ No test cases found!")
#         return None, requirements, 0, 0, [], None
    
#     print(f"📊 Processing: {len(requirements)} reqs, {len(testcases_data)} test cases")
    
#     # Embeddings
#     req_texts = [r["text"] for r in requirements]
#     req_emb = embedder.encode(req_texts, convert_to_numpy=True, normalize_embeddings=True)
#     tc_texts = [tc['text'] for tc in testcases_data]
#     tc_emb = embedder.encode(tc_texts, convert_to_numpy=True, normalize_embeddings=True)
    
#     sim_matrix = cosine_similarity(req_emb, tc_emb)
    
#     # PRIORITIZE ALL TEST CASES
#     prioritized_testcases = prioritize_testcases_from_scores(sim_matrix, testcases_data, requirements)
    
#     # EXPORT YOUR 4-COLUMN FORMAT
#     xlsx_path = export_prioritized_xlsx(prioritized_testcases, output_dir)
    
#     # Coverage calculation
#     coverage = {}
#     missing = []
#     accuracy_scores = []
    
#     for i, req in enumerate(requirements):
#         matches = []
#         for j, tc_text in enumerate(tc_texts):
#             if sim_matrix[i][j] >= SEMANTIC_THRESHOLD:
#                 try:
#                     logits = nli_model.predict([(tc_text, req["text"])])[0]
#                     probs = softmax(logits)
#                     entailment = probs[2]
#                     if entailment >= NLI_THRESHOLD:
#                         matches.append({"testcase": tc_text, "score": float(entailment)})
#                         accuracy_scores.append(entailment)
#                 except:
#                     continue
        
#         if matches:
#             coverage[req["text"]] = {"matches": matches}
#         else:
#             missing.append(req["text"])
    
#     total = len(requirements)
#     covered = len(coverage)
#     completeness = (covered / total) * 100 if total else 0
#     accuracy = np.mean(accuracy_scores) * 100 if accuracy_scores else 0
    
#     print("\n" + "="*80)
#     print("✅ VALIDATION COMPLETE!")
#     print(f"📈 Coverage: {covered}/{total} ({completeness:.1f}%)")
#     print(f"📄 XLSX (4 columns): {xlsx_path}")
    
#     high_count = len([tc for tc in prioritized_testcases if tc['priority'] == 'high'])
#     print(f"🔴 HIGH Priority: {high_count}/{len(prioritized_testcases)}")
    
#     return coverage, missing, completeness, accuracy, prioritized_testcases, xlsx_path

# if __name__ == "__main__":
#     validate_testcases(
#         requirement_file=Path("high_accuracy_requirements.json"),
#         testcase_file=Path("testcases.txt"),
#         output_dir=r"C:/Users/Divya/Desktop/TestCases_G_V/data/output/testcases"
#     )







import json
import numpy as np
import pandas as pd
from pathlib import Path
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.metrics.pairwise import cosine_similarity
from scipy.special import softmax
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import re
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Your existing imports continue...
from config import (
    MODE,
    SEMANTIC_THRESHOLD,
    NLI_THRESHOLD,
    COMPLETENESS_THRESHOLD,
    ACCURACY_THRESHOLD,
)

import warnings
import logging
import os

# Suppress model warnings
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
logging.getLogger("transformers.modeling_utils").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message=".*position_ids.*")


# Models
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

embedder = SentenceTransformer(EMBEDDING_MODEL)
nli_model = CrossEncoder(NLI_MODEL)


from pathlib import Path
# ... your existing imports

# 2. ADD load_json function (if missing)
def load_json(path: Path):
    if path.exists():
        try:
            data = path.read_text(encoding="utf-8").strip()
            if not data:
                return []
            return json.loads(data)
        except json.JSONDecodeError:
            print(f"Warning: {path} contains invalid JSON.")
            return []
    return []

def load_requirements(json_path: Path):
    """Load requirements from JSON - handles encoding issues"""
    try:
        # Try UTF-8 first
        with json_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except UnicodeDecodeError:
        # Fallback: try other encodings
        encodings = ['utf-8-sig', 'latin1', 'cp1252', 'iso-8859-1']
        data = None
        for enc in encodings:
            try:
                with json_path.open("r", encoding=enc) as f:
                    data = json.load(f)
                print(f" Loaded with encoding: {enc}")
                break
            except:
                continue
        
        if data is None:
            print(f" Cannot read JSON file: {json_path}")
            return []
    
    requirements = []
    
    if isinstance(data, dict):
        for section, items in data.items():
            for item in items:
                text = extract_text_from_item(item)
                if len(text) < 10:
                    continue
                requirements.append({"text": text, "category": section})
    elif isinstance(data, list):
        for i, item in enumerate(data):
            text = extract_text_from_item(item)
            if len(text) < 10:
                continue
            requirements.append({"text": text, "category": f"Section_{i}"})
    
    print(f" Loaded {len(requirements)} requirements from {json_path}")
    return requirements


# def load_requirements(json_path: Path):
#     """Load requirements from JSON - handles strings, dicts, nested structures"""
#     with json_path.open("r", encoding="utf-8") as f:
#         data = json.load(f)

#     requirements = []
    
#     # Handle different JSON structures from your pipeline
#     if isinstance(data, dict):
#         # Your classified structure: {"Functional": ["req1", "req2"], ...}
#         for section, items in data.items():
#             for item in items:
#                 text = extract_text_from_item(item)  #  SAFE TEXT EXTRACTION
#                 if len(text) < 10:
#                     continue
#                 requirements.append({
#                     "text": text,
#                     "category": section
#                 })
#     elif isinstance(data, list):
#         # Flat list fallback
#         for i, item in enumerate(data):
#             text = extract_text_from_item(item)
#             if len(text) < 10:
#                 continue
#             requirements.append({
#                 "text": text,
#                 "category": f"Section_{i}"
#             })
    
#     print(f" Loaded {len(requirements)} requirements from {json_path}")
#     return requirements

# ================================
#  NEW: Safe text extraction from ANY item type
# ================================
def extract_text_from_item(item):
    """Extract text from string, dict, or nested structure"""
    if isinstance(item, str):
        return item.strip()
    elif isinstance(item, dict):
        # Extract text from dict values
        texts = []
        for value in item.values():
            if isinstance(value, str):
                texts.append(value.strip())
            elif isinstance(value, (list, dict)):
                texts.append(json.dumps(value, ensure_ascii=False)[:200])
        return " ".join(texts).strip()
    else:
        # Fallback for other types
        return str(item).strip()

# ================================
#  FIXED: Parse YOUR exact testcases.txt - NO BRACKETS IN USERSTORY
# ================================

# def load_testcases(txt_path: Path):
#     print(f"Reading test cases from: {txt_path}")
    
#     with txt_path.open("r", encoding="utf-8") as f:
#         content = f.read()
    
#     print(f"Raw content preview: {content[:500]}...")  # Debug
    
#     testcases = []
    
#     # More flexible parsing for your exact format
#     lines = content.split('\n')
#     current_section = None
#     section_mapping = {'Positive': 'positive', 'Negative': 'negative', 'Boundary': 'boundary'}
    
#     for line in lines:
#         line = line.strip()
        
#         # Detect section headers (case insensitive, flexible)
#         for sec_name in section_mapping:
#             if line.lower().startswith(sec_name.lower() + ':'):
#                 current_section = section_mapping[sec_name]
#                 print(f"Found section: {current_section}")
#                 continue
        
#         # Extract test cases (more flexible keywords)
#         if current_section and line and len(line) > 20:
#             line_lower = line.lower()
#             if any(keyword in line_lower for keyword in ['verify', 'validate', 'ensure', 'check', 'test', 'confirm']):
#                 testcases.append({
#                     "text": line,
#                     "full_text": line,
#                     "distribution": current_section
#                 })
    
#     print(f"Found {len(testcases)} test cases")
#     if testcases:
#         print(f"Sample: {testcases[0]['text'][:100]}")
#     return testcases




# ✅ REPLACE your load_testcases() function ONLY
def load_testcases(testcase_path: Path):
    """Load test cases from JSON (testcases.json) OR TXT (backward compatible)"""
    print(f"Reading test cases from: {testcase_path}")
    
    if testcase_path.suffix == '.json':
        # ✅ NEW: Handle your testcases.json format
        testcases_data = load_json(testcase_path)
        testcases = []
        for item in testcases_data:
            user_story_id = item.get('user_story_id'),
            user_story = item.get('user_story'),
            tc_text = item.get("test_case", "")
            test_case_id = item.get('test_case_id'),
            distribution = item.get("distribution", "positive").lower()
            priority= item.get('priority'),
            
            testcases.append({
                "text": tc_text[:500],        # Short for similarity calc
                "full_text": tc_text,         # Full for Excel column
                "distribution": distribution  # positive/negative/boundary
            })
        print(f"✅ Loaded {len(testcases)} test cases from JSON")
        
    else:
        # ✅ OLD: Handle testcases.txt (backward compatible)
        with testcase_path.open("r", encoding="utf-8") as f:
            content = f.read()
        
        testcases = []
        lines = content.split('\n')
        current_section = None
        section_mapping = {'Positive': 'positive', 'Negative': 'negative', 'Boundary': 'boundary'}
        
        for line in lines:
            line = line.strip()
            for sec_name in section_mapping:
                if line.lower().startswith(sec_name.lower() + ':'):
                    current_section = section_mapping[sec_name]
                    continue
            if current_section and line and len(line) > 20:
                line_lower = line.lower()
                if any(keyword in line_lower for keyword in ['verify', 'validate', 'ensure', 'check']):
                    testcases.append({
                        "text": line,
                        "full_text": line,
                        "distribution": current_section
                    })
    
    print(f"Found {len(testcases)} test cases")
    if testcases:
        print(f"Sample: {testcases[0]['text'][:100]}")
    return testcases





# def load_testcases(txt_path: Path):
#     print(f" Reading test cases from: {txt_path}")
    
#     with txt_path.open("r", encoding="utf-8") as f:
#         content = f.read()
    
#     testcases = []
    
#     # Split by sections exactly matching your format
#     sections_raw = re.split(r'(?=^(Positive|Negative|Boundary):)', content, flags=re.MULTILINE | re.IGNORECASE)
    
#     current_section = None
#     section_mapping = {'Positive': 'positive', 'Negative': 'negative', 'Boundary': 'boundary'}
    
#     for section_part in sections_raw:
#         section_part = section_part.strip()
        
#         # Detect section
#         for sec_name in section_mapping:
#             if section_part.startswith(f"{sec_name}:"):
#                 current_section = section_mapping[sec_name]
#                 section_part = section_part.replace(f"{sec_name}:", "").strip()
#                 break
        
#         # Extract test cases
#         if current_section:
#             lines = section_part.split('\n')
#             for line in lines:
#                 line = line.strip()
#                 if (line and len(line) > 20 and 
#                     ('verify' in line.lower() or 'validate' in line.lower() or 'ensure' in line.lower())):
                    
#                     testcases.append({
#                         "text": line,
#                         "full_text": line,  #  CLEAN - NO BRACKETS IN USERSTORY
#                         "distribution": current_section  # Type for last column
#                     })
    
#     print(f" Found {len(testcases)} test cases")
#     return testcases

# ================================
# PRIORITIZATION USING VALIDATOR SCORES (UNCHANGED)
# ================================
def prioritize_testcases_from_scores(sim_matrix: np.ndarray, testcases: list, requirements: list):
    testcase_scores = []
    
    for j, tc_data in enumerate(testcases):
        tc_text = tc_data['text']
        
        # 1. Average similarity (35%)
        avg_similarity = np.mean(sim_matrix[:, j])
        
        # 2. Coverage ratio (25%)
        covered_reqs = sum(1 for i in range(len(requirements)) if sim_matrix[i][j] >= SEMANTIC_THRESHOLD)
        coverage_ratio = min(covered_reqs / len(requirements), 1.0)
        
        # 3. Best entailment score (20%)
        best_entailment = 0.0
        for i, req_text in enumerate([r["text"] for r in requirements]):
            try:
                logits = nli_model.predict([(tc_text, req_text)])[0]
                probs = softmax(logits)
                best_entailment = max(best_entailment, probs[2])
            except:
                continue
        
        # 4. Risk score (10%)
        risk_keywords = ['security', 'login', 'payment', 'error', 'auth', 'critical', 'fee', '966', 'public sector']
        risk_score = 0.9 if any(kw in tc_text.lower() for kw in risk_keywords) else 0.5
        
        # 5. Scenario bonus (10%)
        scenario_bonus = 1.0 if tc_data['distribution'] == 'negative' else 0.8 if tc_data['distribution'] == 'boundary' else 0.7
        
        priority_score = (
            avg_similarity * 0.35 +
            coverage_ratio * 0.25 +
            best_entailment * 0.20 +
            risk_score * 0.10 +
            scenario_bonus * 0.10
        )
        
        priority_rank = 'high' if priority_score > 0.7 else 'medium' if priority_score > 0.45 else 'low'
        
        testcase_scores.append({
            'id': None,  # Sequential numbering later
            'userstory': tc_data['full_text'],  #  CLEAN USERSTORY (NO BRACKETS)
            'priority': priority_rank,  # high/medium/low
            'testcases distribution': tc_data['distribution'],  # ACTUAL: positive/negative/boundary
            'priority_score': priority_score,
            'distribution': tc_data['distribution']  # For internal use
        })
    
    # Sort by priority (HIGH FIRST)
    prioritized = sorted(testcase_scores, key=lambda x: x['priority_score'], reverse=True)
    
    #  SEQUENTIAL IDS STARTING FROM 101
    for i, tc in enumerate(prioritized, 101):
        tc['id'] = i
    
    return prioritized

# ================================
#  4 COLUMNS PERFECT FORMAT (UNCHANGED)
# ================================
def export_prioritized_xlsx(prioritized_testcases, output_dir):
    OUTPUT_PATH = Path(output_dir)
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    
    #  YOUR EXACT 4-COLUMN FORMAT
    excel_data = []
    for tc in prioritized_testcases:
        excel_data.append({
            'id': tc['id'],
            'userstory': tc['userstory'],  # CLEAN Verify that...
            'priority': tc['priority'],  # high/medium/low
            'testcases distribution': tc['testcases distribution']  # positive/negative/boundary
        })
    
    df = pd.DataFrame(excel_data)
    xlsx_path = OUTPUT_PATH / "testcases.xlsx"
    
    with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='TestCases', index=False)
        
        worksheet = writer.sheets['TestCases']
        
        # Headers
        headers = ['id', 'userstory', 'priority', 'testcases distribution']
        header_font = Font(bold=True, color="FFFFFF", size=12)
        header_fill = PatternFill(start_color="2E75B6", end_color="2E75B6", fill_type="solid")
        
        for col_num, header in enumerate(headers, 1):
            cell = worksheet.cell(row=1, column=col_num)
            cell.value = header
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Auto-adjust column widths
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 80)
            worksheet.column_dimensions[column_letter].width = adjusted_width
        
        # Color code PRIORITY column (Column C)
        for row in range(2, len(df)+2):
            priority_cell = worksheet.cell(row=row, column=3)  # Priority column
            dist_cell = worksheet.cell(row=row, column=4)      # Distribution column
            
            priority = df.iloc[row-2]['priority']
            
            # Priority colors (Column C)
            if priority == 'high':
                priority_cell.fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
                priority_cell.font = Font(color="D32F2F", bold=True)
            elif priority == 'medium':
                priority_cell.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
                priority_cell.font = Font(color="F57C00", bold=True)
            else:  # low
                priority_cell.fill = PatternFill(start_color="E8F5E8", end_color="E8F5E8", fill_type="solid")
                priority_cell.font = Font(color="2E7D32", bold=True)
            
            # Distribution colors (Column D)
            dist_value = df.iloc[row-2]['testcases distribution']
            if dist_value == 'positive':
                dist_cell.fill = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")
                dist_cell.font = Font(color="1976D2", bold=True)
            elif dist_value == 'negative':
                dist_cell.fill = PatternFill(start_color="FFEBEE", end_color="FFEBEE", fill_type="solid")
                dist_cell.font = Font(color="D32F2F", bold=True)
            else:  # boundary
                dist_cell.fill = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid")
                dist_cell.font = Font(color="F57C00", bold=True)
    
    print(f" XLSX EXPORTED: {xlsx_path}")
    return xlsx_path

# ================================
# MAIN VALIDATOR (UNCHANGED)
# ================================
def validate_testcases(
    requirement_file: Path,
    testcase_file: Path,
    output_dir: str = "data/output/testcases"
):
    print(" VALIDATOR + PRIORITIZER STARTED")
    
    requirements = load_requirements(requirement_file)
    if not requirements:
        print(" No requirements found!")
        return None, [], 0, 0, [], None
    
    testcases_data = load_testcases(testcase_file)
    if not testcases_data:
        print(" No test cases found!")
        return None, requirements, 0, 0, [], None
    
    print(f" Processing: {len(requirements)} reqs, {len(testcases_data)} test cases")
    
    # Embeddings
    req_texts = [r["text"] for r in requirements]
    req_emb = embedder.encode(req_texts, convert_to_numpy=True, normalize_embeddings=True)
    tc_texts = [tc['text'] for tc in testcases_data]
    tc_emb = embedder.encode(tc_texts, convert_to_numpy=True, normalize_embeddings=True)
    
    sim_matrix = cosine_similarity(req_emb, tc_emb)
    
    # PRIORITIZE ALL TEST CASES
    prioritized_testcases = prioritize_testcases_from_scores(sim_matrix, testcases_data, requirements)
    
    # EXPORT YOUR 4-COLUMN FORMAT
    xlsx_path = export_prioritized_xlsx(prioritized_testcases, output_dir)
    
    # Coverage calculation
    coverage = {}
    missing = []
    accuracy_scores = []
    
    for i, req in enumerate(requirements):
        matches = []
        for j, tc_text in enumerate(tc_texts):
            if sim_matrix[i][j] >= SEMANTIC_THRESHOLD:
                try:
                    logits = nli_model.predict([(tc_text, req["text"])])[0]
                    probs = softmax(logits)
                    entailment = probs[2]
                    if entailment >= NLI_THRESHOLD:
                        matches.append({"testcase": tc_text, "score": float(entailment)})
                        accuracy_scores.append(entailment)
                except:
                    continue
        
        if matches:
            coverage[req["text"]] = {"matches": matches}
        else:
            missing.append(req["text"])
    
    total = len(requirements)
    covered = len(coverage)
    completeness = (covered / total) * 100 if total else 0
    accuracy = np.mean(accuracy_scores) * 100 if accuracy_scores else 0
    
    print("\n" + "="*80)
    print(" VALIDATION COMPLETE!")
    print(f" Coverage: {covered}/{total} ({completeness:.1f}%)")
    print(f" XLSX (4 columns): {xlsx_path}")
    
    high_count = len([tc for tc in prioritized_testcases if tc['priority'] == 'high'])
    print(f" HIGH Priority: {high_count}/{len(prioritized_testcases)}")
    
    return coverage, missing, completeness, accuracy, prioritized_testcases, xlsx_path

# if __name__ == "__main__":
#     validate_testcases(
#         requirement_file=Path("classified_file.json"),
#         testcase_file=Path("testcases.txt"),
#         output_dir="data/output/testcases"
#     )



if __name__ == "__main__":
    validate_testcases(
        requirement_file=Path("classified_file.json"),  # SSD requirements
        testcase_file=Path("testcases.json"),                     # NEW: JSON output
        output_dir="data/output/testcases"
    )