import sys
import json
from pathlib import Path
from data_processing.raw_extraction import extract_docx_sections
from data_processing.data_classification import aggregate_important_requirements
from validator.validator import validate_testcases
from config import PROCESSED_SSD_FILE

# Add project root to sys.path
sys.path.append(str(Path(__file__).parent.parent.resolve()))

def run_cli():
    print(" STANDALONE VALIDATOR CLI")
    print("="*50)
    
    # 1. Get SSD DOCX path
    ssd_docx_path = Path(input(" Enter SSD DOCX path: ").strip())
    if not ssd_docx_path.exists():
        print(" SSD DOCX not found!")
        return
    
    # 2. Extract → Classify
    print(" Extracting DOCX...")
    raw_ssd_data = extract_docx_sections(ssd_docx_path)
    
    print(" Classifying requirements...")
    classified_data = aggregate_important_requirements(raw_ssd_data)
    
    # Save classified JSON
    PROCESSED_SSD_FILE.parent.mkdir(parents=True, exist_ok=True)
    with PROCESSED_SSD_FILE.open("w", encoding="utf-8") as f:
        json.dump(classified_data, f, indent=2, ensure_ascii=False)
    
    print(f" Classified JSON: {PROCESSED_SSD_FILE}")
    
    # 3. Get testcases TXT path
    tc_path = Path(input(" Enter testcases TXT path: ").strip())
    if not tc_path.exists():
        print(" Testcases TXT not found!")
        return
    
    # 4. VALIDATE (handle 6 return values)
    print(" Running validation...")
    result = validate_testcases(
        requirement_file=PROCESSED_SSD_FILE,
        testcase_file=tc_path
    )
    
    if result and len(result) >= 4:
        coverage, missing, completeness, accuracy, prioritized, xlsx_path = result
        print("\n" + "="*80)
        print(" VALIDATION COMPLETE!")
        print(f" Coverage: {completeness:.1f}%")
        print(f" Accuracy: {accuracy:.1f}%")
        print(f" Excel: {xlsx_path}")
        print(f" High Priority: {len([tc for tc in prioritized if tc['priority']=='high'])}")
    else:
        print(" Validation failed!")

if __name__ == "__main__":
    run_cli()




#previous corrected code

# import json
# from json.tool import main
# from pathlib import Path
# from validator.validator import validate_testcases
# from config import MODE
# import sys
# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
#     PROCESSED_SSD_FILE
# )

# from data_processing.raw_extraction import extract_docx_sections
# from data_processing.data_classification import aggregate_important_requirements
# from validator.validator import validate_testcases
# from generator.generator import run_generator


# # Add project root to sys.path
# sys.path.append(str(Path(__file__).parent.parent.resolve()))


# def run_cli():
#     # print("Standalone Validator CLI")

#     # print("Extracting SSD document...")
#     ssd_docx_path = Path(input("Enter path of your SSD : ").strip())
#     raw_ssd_data = extract_docx_sections(ssd_docx_path)


#     # 2) Classify SSD data

#     print("Classifying important requirements...")
#     classified_data = aggregate_important_requirements(raw_ssd_data)

#     PROCESSED_SSD_FILE.parent.mkdir(parents=True, exist_ok=True)
#     with PROCESSED_SSD_FILE.open("w", encoding="utf-8") as f:
#         json.dump(classified_data, f, indent=2, ensure_ascii=False)

#     # print(f"SSD processed and saved to {PROCESSED_SSD_FILE}")
    
#     PROCESSED_SSD_FILE = Path(input("Enter path to SSD json file: ").strip())
#     tc_path = Path(input("Enter path to testcases TXT file: ").strip())

#     if not PROCESSED_SSD_FILE.exists() or not tc_path.exists():
#         print("Invalid file paths provided.")
#         return

#     # Standalone: feedback loop OFF
#     coverage, missing, completeness, accuracy = validate_testcases(
#         requirement_file=PROCESSED_SSD_FILE,
#         testcase_file=tc_path
#     )

#     print("\nValidation completed in Standalone mode.")
    # print(f"Completeness: {completeness}%")
    # print(f"Accuracy: {accuracy}%")
    # print(f"Missing Requirements: {len(missing)}")







# import json
# from pathlib import Path
# from validator.validator import validate_testcases
# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
# )

# def run_cli():
#     print("Standalone Validator CLI")
    
#     ssd_json_path = Path(input("Enter path to SSD json file: ").strip())
#     tc_path = Path(input("Enter path to testcases TXT file: ").strip())

#     # if not ssd_json_path.exists():
#     #     print(f"❌ SSD file not found: {ssd_json_path}")
#     #     return
#     # if not tc_path.exists():
#     #     print(f"❌ Test cases file not found: {tc_path}")
#     #     return

#     # FIXED: Handle 5 return values
#     coverage, missing, completeness, accuracy, orphans = validate_testcases(
#         requirement_file=ssd_json_path,
#         testcase_file=tc_path
#     )

#     print("\n✅ Validation completed!")
#     print(f"📊 Completeness: {completeness:.1f}%")
#     print(f"📊 Accuracy: {accuracy:.1f}%")
#     print(f"❌ Missing Requirements: {len(missing)}")
#     print(f"🧪 Orphan Test Cases: {len(orphans)}")
    
#     if missing:
#         print("\n🔍 MISSING REQUIREMENTS:")
#         for i, req in enumerate(missing[:5], 1):  # Show top 5
#             print(f"  {i}. {req['requirement'][:100]}...")
    
#     if orphans:
#         print(f"\n⚠️  ORPHAN TEST CASES: {len(orphans)} tests don't cover any requirements")

# if __name__ == "__main__":
#     run_cli()





