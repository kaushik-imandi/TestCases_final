import json
import numpy as np
import pandas as pd
from pathlib import Path
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.metrics.pairwise import cosine_similarity
from scipy.special import softmax
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import re
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import (
    MODE,
    SEMANTIC_THRESHOLD,
    NLI_THRESHOLD,
    COMPLETENESS_THRESHOLD,
    ACCURACY_THRESHOLD,
)

import warnings
import logging

# Suppress model warnings
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
logging.getLogger("transformers.modeling_utils").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message=".*position_ids.*")

# Models
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

embedder = SentenceTransformer(EMBEDDING_MODEL)
nli_model = CrossEncoder(NLI_MODEL)

def load_json(path: Path):
    if path.exists():
        try:
            data = path.read_text(encoding="utf-8").strip()
            if not data:
                return []
            return json.loads(data)
        except json.JSONDecodeError:
            print(f"Warning: {path} contains invalid JSON.")
            return []
    return []

def load_requirements(json_path: Path):
    """Load requirements from JSON - handles encoding issues"""
    try:
        with json_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except UnicodeDecodeError:
        encodings = ['utf-8-sig', 'latin1', 'cp1252', 'iso-8859-1']
        data = None
        for enc in encodings:
            try:
                with json_path.open("r", encoding=enc) as f:
                    data = json.load(f)
                print(f" Loaded with encoding: {enc}")
                break
            except:
                continue
        
        if data is None:
            print(f" Cannot read JSON file: {json_path}")
            return []
    
    requirements = []
    if isinstance(data, dict):
        for section, items in data.items():
            for item in items:
                text = extract_text_from_item(item)
                if len(text) < 10:
                    continue
                requirements.append({"text": text, "category": section})
    elif isinstance(data, list):
        for i, item in enumerate(data):
            text = extract_text_from_item(item)
            if len(text) < 10:
                continue
            requirements.append({"text": text, "category": f"Section_{i}"})
    
    print(f" Loaded {len(requirements)} requirements from {json_path}")
    return requirements

def extract_text_from_item(item):
    """Extract text from string, dict, or nested structure"""
    if isinstance(item, str):
        return item.strip()
    elif isinstance(item, dict):
        texts = []
        for value in item.values():
            if isinstance(value, str):
                texts.append(value.strip())
            elif isinstance(value, (list, dict)):
                texts.append(json.dumps(value, ensure_ascii=False)[:200])
        return " ".join(texts).strip()
    else:
        return str(item).strip()

def load_testcases(testcase_path: Path):
    """Load test cases from JSON with ALL fields preserved"""
    print(f"Reading test cases from: {testcase_path}")
    
    testcases_data = load_json(testcase_path)
    testcases = []
    
    for item in testcases_data:
        # ✅ PRESERVE ALL JSON FIELDS
        testcases.append({
            "user_story_id": item.get("user_story_id", ""),
            "user_story": item.get("user_story", ""),
            "test_case_id": item.get("test_case_id", ""),
            "test_case": item.get("test_case", ""),
            "distribution": item.get("distribution", "positive").lower(),
            "priority": item.get("priority", "medium").lower(),
            "section": item.get("section", ""),
            "text": item.get("test_case", "")[:500],  # For similarity calculation
            "full_text": item.get("test_case", "")    # For Excel
        })
    
    print(f"✅ Loaded {len(testcases)} test cases from JSON with all fields")
    if testcases:
        print(f"Sample: {testcases[0]['test_case'][:100]}...")
    return testcases

def prioritize_testcases_from_scores(sim_matrix: np.ndarray, testcases: list, requirements: list):
    testcase_scores = []
    
    for j, tc_data in enumerate(testcases):
        tc_text = tc_data['text']
        
        # 1. Average similarity (35%)
        avg_similarity = np.mean(sim_matrix[:, j])
        
        # 2. Coverage ratio (25%)
        covered_reqs = sum(1 for i in range(len(requirements)) if sim_matrix[i][j] >= SEMANTIC_THRESHOLD)
        coverage_ratio = min(covered_reqs / len(requirements), 1.0)
        
        # 3. Best entailment score (20%)
        best_entailment = 0.0
        for i, req_text in enumerate([r["text"] for r in requirements]):
            try:
                logits = nli_model.predict([(tc_text, req_text)])[0]
                probs = softmax(logits)
                best_entailment = max(best_entailment, probs[2])
            except:
                continue
        
        # 4. Risk score (10%)
        risk_keywords = ['security', 'login', 'payment', 'error', 'auth', 'critical', 'fee', '966', 'public sector']
        risk_score = 0.9 if any(kw in tc_text.lower() for kw in risk_keywords) else 0.5
        
        # 5. Scenario bonus (10%)
        scenario_bonus = 1.0 if tc_data['distribution'] == 'negative' else 0.8 if tc_data['distribution'] == 'boundary' else 0.7
        
        priority_score = (
            avg_similarity * 0.35 +
            coverage_ratio * 0.25 +
            best_entailment * 0.20 +
            risk_score * 0.10 +
            scenario_bonus * 0.10
        )
        
        # ✅ NEW: Use validator score as FINAL priority, keep JSON priority as reference
        validator_priority = 'high' if priority_score > 0.7 else 'medium' if priority_score > 0.45 else 'low'
        
        testcase_scores.append({
            'user_story_id': tc_data['user_story_id'],
            'test_case_id': tc_data['test_case_id'],
            'user_story': tc_data['user_story'],
            'test_case': tc_data['full_text'],
            'distribution': tc_data['distribution'],
            'llm_priority': tc_data['priority'],  # Original from generator
            'validator_priority': validator_priority,  # NEW from semantic analysis
            'priority_score': priority_score,
            'section': tc_data['section']
        })
    
    # Sort by validator priority score (HIGH FIRST)
    prioritized = sorted(testcase_scores, key=lambda x: x['priority_score'], reverse=True)
    
    # Sequential numbering for Excel (TC_001 format preserved)
    for i, tc in enumerate(prioritized):
        tc['excel_id'] = i + 1
    
    return prioritized

def export_prioritized_xlsx(prioritized_testcases, output_dir):
    OUTPUT_PATH = Path(output_dir)
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    
    # ✅ NEW 6-COLUMN FORMAT
    excel_data = []
    for tc in prioritized_testcases:
        excel_data.append({
            'User Story ID': tc['user_story_id'],
            'Test Case ID': tc['test_case_id'],
            'User Story': tc['user_story'][:100],  # Truncate for Excel
            'Test Case': tc['test_case'],
            'Distribution': tc['distribution'].title(),
            'Priority': tc['validator_priority'].title()  # Use validator priority
        })
    
    df = pd.DataFrame(excel_data)
    xlsx_path = OUTPUT_PATH / "testcases.xlsx"
    
    with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='TestCases', index=False)
        
        worksheet = writer.sheets['TestCases']
        
        # Headers
        headers = ['User Story ID', 'Test Case ID', 'User Story', 'Test Case', 'Distribution', 'Priority']
        header_font = Font(bold=True, color="FFFFFF", size=12)
        header_fill = PatternFill(start_color="2E75B6", end_color="2E75B6", fill_type="solid")
        
        for col_num, header in enumerate(headers, 1):
            cell = worksheet.cell(row=1, column=col_num)
            cell.value = header
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Auto-adjust column widths
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 80)
            worksheet.column_dimensions[column_letter].width = adjusted_width
        
        # Color code PRIORITY column (Column F)
        for row in range(2, len(df)+2):
            priority_cell = worksheet.cell(row=row, column=6)  # Priority column
            dist_cell = worksheet.cell(row=row, column=5)      # Distribution column
            
            priority = df.iloc[row-2]['Priority']
            
            # Priority colors (Column F)
            if priority == 'High':
                priority_cell.fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
                priority_cell.font = Font(color="D32F2F", bold=True)
            elif priority == 'Medium':
                priority_cell.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
                priority_cell.font = Font(color="F57C00", bold=True)
            else:  # Low
                priority_cell.fill = PatternFill(start_color="E8F5E8", end_color="E8F5E8", fill_type="solid")
                priority_cell.font = Font(color="2E7D32", bold=True)
            
            # Distribution colors (Column E)
            dist_value = df.iloc[row-2]['Distribution']
            if dist_value == 'Positive':
                dist_cell.fill = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")
                dist_cell.font = Font(color="1976D2", bold=True)
            elif dist_value == 'Negative':
                dist_cell.fill = PatternFill(start_color="FFEBEE", end_color="FFEBEE", fill_type="solid")
                dist_cell.font = Font(color="D32F2F", bold=True)
            else:  # Boundary
                dist_cell.fill = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid")
                dist_cell.font = Font(color="F57C00", bold=True)
    
    print(f" ✅ XLSX EXPORTED (6 columns): {xlsx_path}")
    return xlsx_path

def validate_testcases(
    requirement_file: Path,
    testcase_file: Path,
    output_dir: str = "output"
):
    print("🔥 VALIDATOR + PRIORITIZER STARTED")
    
    requirements = load_requirements(requirement_file)
    if not requirements:
        print("❌ No requirements found!")
        return None, [], 0, 0, [], None
    
    testcases_data = load_testcases(testcase_file)
    if not testcases_data:
        print("❌ No test cases found!")
        return None, requirements, 0, 0, [], None
    
    print(f"🚀 Processing: {len(requirements)} reqs, {len(testcases_data)} test cases")
    
    # Embeddings - USE test_case text for similarity
    req_texts = [r["text"] for r in requirements]
    req_emb = embedder.encode(req_texts, convert_to_numpy=True, normalize_embeddings=True)
    tc_texts = [tc['text'] for tc in testcases_data]
    tc_emb = embedder.encode(tc_texts, convert_to_numpy=True, normalize_embeddings=True)
    
    sim_matrix = cosine_similarity(req_emb, tc_emb)
    
    # PRIORITIZE using validator scores
    prioritized_testcases = prioritize_testcases_from_scores(sim_matrix, testcases_data, requirements)
    
    # EXPORT 6-COLUMN FORMAT
    xlsx_path = export_prioritized_xlsx(prioritized_testcases, output_dir)
    
    # Coverage calculation
    coverage = {}
    missing = []
    accuracy_scores = []
    
    for i, req in enumerate(requirements):
        matches = []
        for j, tc_text in enumerate(tc_texts):
            if sim_matrix[i][j] >= SEMANTIC_THRESHOLD:
                try:
                    logits = nli_model.predict([(tc_text, req["text"])])[0]
                    probs = softmax(logits)
                    entailment = probs[2]
                    if entailment >= NLI_THRESHOLD:
                        matches.append({"testcase": tc_text, "score": float(entailment)})
                        accuracy_scores.append(entailment)
                except:
                    continue
        
        if matches:
            coverage[req["text"]] = {"matches": matches}
        else:
            missing.append(req["text"])
    
    total = len(requirements)
    covered = len(coverage)
    completeness = (covered / total) * 100 if total else 0
    accuracy = np.mean(accuracy_scores) * 100 if accuracy_scores else 0
    
    print("\n" + "="*80)
    print("✅ VALIDATION COMPLETE!")
    print(f"📊 Coverage: {covered}/{total} ({completeness:.1f}%)")
    print(f"📁 XLSX (6 columns): {xlsx_path}")
    
    high_count = len([tc for tc in prioritized_testcases if tc['validator_priority'] == 'high'])
    print(f"🔥 HIGH Priority: {high_count}/{len(prioritized_testcases)}")
    
    return coverage, missing, completeness, accuracy, prioritized_testcases, xlsx_path

if __name__ == "__main__":
    validate_testcases(
        requirement_file=Path("../generator/classified_file.json"),  # SSD requirements
        testcase_file=Path("../generator/testcases.json"),          # Generator output
        output_dir="output"
    )
