#!/usr/bin/env python3

import re
import argparse
from pathlib import Path
from openpyxl import Workbook


def parse_user_stories(text: str) -> list[dict]:
    """
    Parse:
        User StoryUS‑001
        Requirement : ...
        Requirement Description : ...
    into list of dicts.
    """
    lines = text.strip().splitlines()
    stories = []
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        m = re.match(r"User StoryUS[‑-](\d+)", line)
        if m:
            user_story_id = m.group(1).zfill(3)
            i += 1

            requirement = ""
            description = ""

            if i < len(lines):
                req_line = lines[i].strip()
                if req_line.startswith("Requirement : "):
                    requirement = req_line[len("Requirement : "):].strip()
                else:
                    requirement = req_line
                i += 1

            if i < len(lines):
                desc_line = lines[i].strip()
                if desc_line.startswith("Requirement Description : "):
                    description = desc_line[len("Requirement Description : "):].strip()
                else:
                    description = desc_line
                i += 1

            stories.append({
                "User Story": f"US_{user_story_id}",
                "Requirement": requirement,
                "Requirement Description": description,
            })
        else:
            i += 1

    return stories


def save_to_xlsx(stories: list[dict], filepath: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "User Stories"

    ws.append(["User Story", "Requirement", "Requirement Description"])

    for s in stories:
        ws.append([
            s["User Story"],
            s["Requirement"],
            s["Requirement Description"],
        ])

    wb.save(str(filepath))
    print(f"User stories saved to {filepath}")


def main():
    parser = argparse.ArgumentParser(description="Convert user stories text to XLSX.")
    parser.add_argument(
        "user_stories_file",
        type=Path,
        help="Path to user stories file (e.g., user_stories.txt)"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("user_stories.xlsx"),
        help="Output XLSX file (default: user_stories.xlsx)"
    )
    args = parser.parse_args()

    if not args.user_stories_file.exists():
        print(f"File not found: {args.user_stories_file}")
        return

    text = args.user_stories_file.read_text(encoding="utf-8")
    stories = parse_user_stories(text)

    if not stories:
        print("No user stories parsed. Check format.")
        return

    save_to_xlsx(stories, args.output)


if __name__ == "__main__":
    main()
