# """
# Testcase_G_V/app.py - Streamlit UI for your pipeline
# NO CHANGES to your existing files needed!
# """

# import streamlit as st
# import os
# import shutil
# import json
# import pandas as pd
# from pathlib import Path
# import subprocess
# import time

# # ✅ IMPORT YOUR EXACT FUNCTIONS
# from data_processing.raw_extraction import extract_docx_sections
# from data_processing.data_classification import aggregate_important_requirements
# from generator.generator import run_generator  # Fixed typo in your structure
# from validator.validator import validate_testcases  # Your validator main func
# from config import FORCE_REGENERATE

# # Page Config
# st.set_page_config(
#     page_title="🧪 TestCase AI Pipeline",
#     page_icon="🧪",
#     layout="wide"
# )

# st.title("🧪 TestCase AI Generator & Validator")
# st.markdown("**Upload SSD → Extract → Classify → Generate → Validate**")

# # ✅ Sidebar Controls
# st.sidebar.header("⚙️ Settings")
# MODEL = st.sidebar.selectbox("Ollama Model", ["mistral", "llama3.2"])
# FORCE_REGENERATE = st.sidebar.checkbox("Force Regenerate", value=False)

# st.sidebar.markdown("---")
# st.sidebar.info("""
# 1. 📁 **Upload DOCX** 
# 2. 🔄 **Extract → Classify** 
# 3. ⚡ **Generate Test Cases**
# 4. ✅ **Validate**
# """)

# # ✅ MAIN TABS - Your Exact Pipeline
# tab1, tab2, tab3, tab4, tab5 = st.tabs([
#     "📁 Upload SSD", 
#     "🔍 Extract & Classify", 
#     "⚡ Generate", 
#     "✅ Validate", 
#     "📊 Results"
# ])

# # ===== TAB 1: UPLOAD SSD =====
# with tab1:
#     st.header("Step 1: Upload DOCX SSDs")
    
#     uploaded_files = st.file_uploader(
#         "Choose DOCX files", 
#         type=['docx'],
#         accept_multiple_files=True,
#         help="Upload your SSD documents"
#     )
    
#     if uploaded_files:
#         # Save to input folder
#         os.makedirs("data/input/SSDs", exist_ok=True)
#         saved_files = []
        
#         for file in uploaded_files:
#             filepath = f"data/input/SSDs/{file.name}"
#             with open(filepath, "wb") as f:
#                 f.write(file.getbuffer())
#             saved_files.append(filepath)
#             st.success(f"✅ Saved: {file.name}")
        
#         st.session_state.ssd_files = saved_files
#         st.rerun()

# # ===== TAB 2: EXTRACT + CLASSIFY =====  
# with tab2:
#     st.header("Step 2: Extract Structure & Classify Requirements")
    
#     if 'ssd_files' not in st.session_state:
#         st.warning("👈 Upload SSDs first!")
#     else:
#         if st.button("🚀 Run Extraction + Classification", type="primary"):
#             with st.spinner("Extracting sections..."):
#                 # ✅ YOUR row_extraction
#                 json_files = []
#                 for ssd_file in st.session_state.ssd_files:
#                     structured = extract_docx_sections(ssd_file)
#                     json_path = f"data/output/{Path(ssd_file).stem}_structured.json"
#                     with open(json_path, 'w', encoding='utf-8') as f:
#                         json.dump(structured, f, indent=2, ensure_ascii=False)
#                     json_files.append(json_path)
                
#                 st.success("✅ Extraction complete!")
            
#             # ✅ YOUR data_classification
#             with st.spinner("Classifying requirements..."):
#                 all_classified = {}
#                 for json_file in json_files:
#                     structured = json.load(open(json_file))
#                     classified = aggregate_important_requirements(structured)
#                     classified_file = f"data/output/{Path(json_file).stem}_classified.json"
#                     with open(classified_file, 'w', encoding='utf-8') as f:
#                         json.dump(classified, f, indent=2, ensure_ascii=False)
#                     all_classified.update(classified)
                
#                 st.session_state.classified = all_classified
#                 st.balloons()
#                 st.success("🎉 Classification complete!")
            
#             # Preview
#             if st.session_state.classified:
#                 st.subheader("📋 Classified Requirements")
#                 for cat, reqs in st.session_state.classified.items():
#                     with st.expander(f"{cat} ({len(reqs)} reqs)"):
#                         for req in reqs[:3]:  # First 3
#                             st.write(f"• {req[:200]}...")

# # ===== TAB 3: GENERATE TEST CASES =====
# with tab3:
#     st.header("Step 3: Generate Test Cases")
    
#     col1, col2 = st.columns(2)
#     with col1:
#         master_req_file = "data/output/master_classified.json"
#         new_req_file = "data/output/new_classified.json"
#         testcase_file = Path("data/output/alltestcases/testcases.txt")
#         hash_file = Path("data/output/testcase_hash.txt")
    
#     with col2:
#         if st.button("⚡ Generate Test Cases", type="primary", use_container_width=True):
#             with st.spinner("🤖 AI generating Positive/Negative/Boundary..."):
#                 # ✅ YOUR generator (exact call!)
#                 run_generator(
#                     master_requirement_file=Path(master_req_file),
#                     new_requirement_file=Path(new_req_file) if os.path.exists(new_req_file) else None,
#                     output_testcase_file=testcase_file,
#                     hash_file=hash_file
#                 )
#                 st.rerun()
    
#     # Preview generated test cases
#     testcase_path = "data/output/alltestcases/testcases.txt"
#     if os.path.exists(testcase_path):
#         with open(testcase_path, 'r') as f:
#             content = f.read()
#         st.text_area("Generated Test Cases", content, height=400)
#         st.download_button("📥 Download testcases.txt", content, "testcases.txt")

# # ===== TAB 4: VALIDATE =====
# with tab4:
#     st.header("Step 4: Validate Test Cases")
    
#     if st.button("🔍 Run Validator", type="primary"):
#         with st.spinner("🔬 Running validation checks..."):
#             # ✅ YOUR validator
#             results = validate_testcases()  # Returns dict or df
            
#             # Display results
#             if isinstance(results, dict):
#                 for metric, score in results.items():
#                     st.metric(metric, f"{score}%")
#             elif isinstance(results, pd.DataFrame):
#                 st.dataframe(results)
            
#             st.success("✅ Validation Complete!")

# # ===== TAB 5: RESULTS DASHBOARD =====
# # ===== TAB 5: RESULTS DASHBOARD =====
# with tab5:
#     st.header("📊 Pipeline Results")
    
#     # ✅ FIXED: Convert generators to lists
#     col1, col2, col3, col4 = st.columns(4)
    
#     ssd_count = len(list(Path("data/input/SSDs").glob("*.docx")))  # ✅ list()
#     json_count = len(list(Path("data/output").glob("*_classified.json")))  # ✅ list()
    
#     testcase_file = Path("data/output/alltestcases/testcases.txt")
#     testcase_lines = 0
#     if testcase_file.exists():
#         testcase_lines = len(testcase_file.read_text().splitlines())  # ✅ Fixed
    
#     col1.metric("📁 SSDs", ssd_count)
#     col2.metric("📋 JSONs", json_count)
#     col3.metric("🧪 Test Cases", testcase_lines)
#     col4.metric("✅ Status", "Complete" if testcase_file.exists() else "Pending")

    
#     # Folder tree
#     st.subheader("📂 Folder Structure")
#     st.code("""
# Testcase_G_V/
# ├── data/input/SSDs/           ✅ Your uploads
# ├── data/output/*.json         ✅ Extracted + Classified
# ├── data/output/alltestcases/  ✅ Generated testcases.txt
# ├── data_processing/           ✅ Your scripts
# ├── generator/
# ├── validator/
# └── app.py                     ✅ This UI
#     """)

# # ✅ RUN CHECKS
# if not os.path.exists("data"):
#     os.makedirs("data/output/alltestcases", exist_ok=True)
#     st.sidebar.success("✅ Folders ready!")

# st.markdown("---")
# st.markdown("*Powered by your exact pipeline*")





















"""
Testcase_G_V/main_app.py - Streamlit UI with MODE selection
Works with your EXACT config.py + file structure
"""

# import streamlit as st
# import os
# import shutil
# import json
# import pandas as pd
# from pathlib import Path
# import subprocess
# import time

# # ✅ IMPORT YOUR EXACT FUNCTIONS
# from data_processing.raw_extraction import extract_docx_sections
# from data_processing.data_classification import aggregate_important_requirements
# from generator.generator import run_generator  # Fixed typo in your structure
# from validator.validator import validate_testcases  # Your validator main func
# from config import FORCE_REGENERATE
# from config import (
#     MODE,
#     SEMANTIC_THRESHOLD,
#     NLI_THRESHOLD,
#     COMPLETENESS_THRESHOLD,
#     ACCURACY_THRESHOLD,
#     PROCESSED_SSD_FILE,
#     GENERATED_TESTCASES_FILE
# )

# # Page Config
# st.set_page_config(
#     page_title="🧪 TestCase AI Pipeline",
#     page_icon="🧪",
#     layout="wide"
# )

# st.title("🧪 TestCase AI Generator & Validator")
# st.markdown("**Select Mode → Upload Files → Run Pipeline**")

# # ✅ MODE SELECTION (Top Priority)
# st.sidebar.header("🎛️ SELECT MODE")
# selected_mode = st.sidebar.radio(
#     "Choose Pipeline Mode:",
#     ["INTEGRATED", "STANDALONE"],
#     index=0 if MODE == "INTEGRATED" else 1,
#     help="INTEGRATED: Full pipeline | STANDALONE: Validator only"
# )

# # Update config MODE
# if selected_mode != MODE:
#     st.sidebar.info(f"🔄 Mode changed to: **{selected_mode}**")
#     # For demo, we'll use session state instead of modifying config.py
#     st.session_state.mode = selected_mode

# # ✅ Sidebar Settings
# st.sidebar.header("⚙️ Settings")
# MODEL = st.sidebar.selectbox("Ollama Model", ["mistral", "llama3.2"])
# force_regen = st.sidebar.checkbox("Force Regenerate", value=FORCE_REGENERATE)

# # Create required directories
# os.makedirs("data/input/SSDs", exist_ok=True)
# os.makedirs("data/output/json_data", exist_ok=True)
# os.makedirs("data/output/alltestcases", exist_ok=True)

# # ✅ MAIN TABS
# tab1, tab2, tab3, tab4 = st.tabs(["📁 Upload", "🚀 Run Pipeline", "📊 Results", "📋 Logs"])

# # ===== TAB 1: UPLOAD FILES =====
# with tab1:
#     st.header("📁 File Upload")
    
#     if selected_mode == "INTEGRATED":
#         st.info("🟢 **INTEGRATED MODE**: Upload SSD DOCX → Full Pipeline")
#         uploaded_ssd = st.file_uploader(
#             "Upload SSD DOCX", type=['docx'], key="ssd_integrated"
#         )
#         if uploaded_ssd:
#             filepath = f"data/input/SSDs/{uploaded_ssd.name}"
#             with open(filepath, "wb") as f:
#                 f.write(uploaded_ssd.getbuffer())
#             st.session_state.ssd_path = filepath
#             st.success(f"✅ SSD saved: {uploaded_ssd.name}")
    
#     else:  # STANDALONE
#         st.info("🔵 **STANDALONE MODE**: Upload SSD JSON + TestCases TXT")
#         col1, col2 = st.columns(2)
#         with col1:
#             uploaded_json = st.file_uploader("SSD JSON", type=['json'], key="ssd_json")
#         with col2:
#             uploaded_txt = st.file_uploader("TestCases TXT", type=['txt'], key="testcases_txt")
        
#         if uploaded_json and uploaded_txt:
#             json_path = f"data/input/SSDs/{uploaded_json.name}"
#             txt_path = f"data/input/SSDs/{uploaded_txt.name}"
#             with open(json_path, "wb") as f:
#                 f.write(uploaded_json.getbuffer())
#             with open(txt_path, "wb") as f:
#                 f.write(uploaded_txt.getbuffer())
#             st.session_state.standalone_json = json_path
#             st.session_state.standalone_txt = txt_path
#             st.success("✅ Files ready for validation!")

# # ===== TAB 2: RUN PIPELINE =====
# with tab2:
#     st.header("🚀 Run Pipeline")
    
#     if selected_mode == "INTEGRATED":
#         st.info("**INTEGRATED MODE**: SSD → Extract → Classify → Generate → Validate → Feedback")
        
#         if st.button("🎯 Run FULL Pipeline", type="primary", use_container_width=True):
#             if 'ssd_path' not in st.session_state:
#                 st.error("👈 Upload SSD first!")
#             else:
#                 with st.spinner("Running FULL pipeline..."):
#                     try:
#                         # 1. Extract
#                         ssd_path = st.session_state.ssd_path
#                         raw_data = extract_docx_sections(ssd_path)
#                         json_path = f"data/output/{Path(ssd_path).stem}_structured.json"
#                         with open(json_path, 'w', encoding='utf-8') as f:
#                             json.dump(raw_data, f, indent=2)
                        
#                         # 2. Classify
#                         classified = aggregate_important_requirements(raw_data)
#                         classified_path = PROCESSED_SSD_FILE
#                         classified_path.parent.mkdir(exist_ok=True)
#                         with open(classified_path, 'w', encoding='utf-8') as f:
#                             json.dump(classified, f, indent=2)
                        
#                         # 3. Generate
#                         run_generator(
#                             master_requirement_file=classified_path,
#                             new_requirement_file=None,
#                             output_testcase_file=GENERATED_TESTCASES_FILE,
#                             hash_file=Path("data/output/requirements.hash")
#                         )
                        
#                         # 4. Validate + Feedback (your exact logic)
#                         for attempt in range(3):  # MAX_FEEDBACK_RETRIES
#                             coverage, missing, completeness, accuracy = validate_testcases(
#                                 requirement_file=classified_path,
#                                 testcase_file=GENERATED_TESTCASES_FILE
#                             )
#                             st.metric("Completeness", f"{completeness}%")
#                             st.metric("Accuracy", f"{accuracy}%")
#                             if completeness >= 95 or not missing:
#                                 break
#                             if missing:
#                                 # Regenerate missing
#                                 missing_json = Path("data/output/new_requirements.json")
#                                 grouped_missing = {}
#                                 for item in missing:
#                                     grouped_missing.setdefault(item.get("category", "General"), 
#                                                              []).append(item["requirement"])
#                                 with open(missing_json, 'w') as f:
#                                     json.dump(grouped_missing, f, indent=2)
#                                 run_generator(
#                                     master_requirement_file=classified_path,
#                                     new_requirement_file=missing_json,
#                                     output_testcase_file=GENERATED_TESTCASES_FILE,
#                                     hash_file=Path("data/output/requirements.hash")
#                                 )
                        
#                         st.balloons()
#                         st.success("🎉 FULL PIPELINE COMPLETE!")
#                     except Exception as e:
#                         st.error(f"❌ Pipeline failed: {e}")
    
#     else:  # STANDALONE
#         st.info("**STANDALONE MODE**: Validate existing test cases")
#         if st.button("🔍 Run Validator Only", type="primary", use_container_width=True):
#             if 'standalone_json' not in st.session_state or 'standalone_txt' not in st.session_state:
#                 st.error("👈 Upload SSD JSON + TestCases TXT first!")
#             else:
#                 with st.spinner("🔬 Running validation..."):
#                     coverage, missing, completeness, accuracy = validate_testcases(
#                         requirement_file=Path(st.session_state.standalone_json),
#                         testcase_file=Path(st.session_state.standalone_txt)
#                     )
#                     st.metric("Completeness", f"{completeness}%")
#                     st.metric("Accuracy", f"{accuracy}%")
#                     st.success("✅ Validation Complete!")
#                     st.json({"coverage": coverage, "missing": missing})

# # ===== TAB 3: RESULTS =====
# with tab3:
#     st.header("📊 Results Dashboard")
#     col1, col2, col3, col4 = st.columns(4)
    
#     ssd_count = len(list(Path("data/input/SSDs").glob("*.docx")))
#     json_count = len(list(Path("data/output").glob("*_classified.json")))
#     testcase_file = GENERATED_TESTCASES_FILE
#     testcase_lines = 0
#     if testcase_file.exists():
#         testcase_lines = len(testcase_file.read_text().splitlines())
    
#     col1.metric("📁 SSDs", ssd_count)
#     col2.metric("📋 JSONs", json_count)
#     col3.metric("🧪 Test Cases", testcase_lines)
#     col4.metric("✅ Status", "Complete" if testcase_file.exists() else "Pending")
    
#     # Preview test cases
#     if testcase_file.exists():
#         st.subheader("Generated Test Cases")
#         with open(testcase_file) as f:
#             st.text_area("", f.read(), height=300)
#         st.download_button("📥 Download", testcase_file, "testcases.txt")

# # ===== TAB 4: LOGS =====
# with tab4:
#     st.header("📋 Folder Structure & Logs")
#     st.code("""
# Testcase_G_V/
# ├── config.py                 ✅ Your config
# ├── data/
# │   ├── input/SSDs/          ✅ Uploaded files
# │   ├── output/json_data/
# │   │   ├── classified_file.json
# │   │   └── validation_report.json
# │   └── output/alltestcases/
# │       └── testcases.txt    ✅ Final output
# ├── data_processing/
# ├── generator/
# └── validator/
#     """)

# # Footer
# st.markdown("---")
# st.markdown("*Powered by your exact pipeline* | INTEGRATED/STANDALONE modes")



import streamlit as st
import os
import json
import pandas as pd
from pathlib import Path
import sys

# Fix imports - Add sys.path for subdirectories
sys.path.append("data_processing")
sys.path.append("generator")
sys.path.append("validator")

#  YOUR EXACT FUNCTIONS (Fixed paths)
from raw_extraction import extract_docx_sections
from data_classification import aggregate_important_requirements
from generator import run_generator
from validator import validate_testcases
from config import (
    MODE, FORCE_REGENERATE, PROCESSED_SSD_FILE, GENERATED_TESTCASES_FILE,
    SEMANTIC_THRESHOLD, NLI_THRESHOLD, COMPLETENESS_THRESHOLD, ACCURACY_THRESHOLD
)

# Page Config
st.set_page_config(page_title="TestCase Generator", page_icon="", layout="wide")

st.title(" GenValidate TestCases")
# st.markdown("**Select Mode → Upload Files → Run Pipeline**")

#  MODE SELECTION
st.sidebar.header("SELECT MODE")
selected_mode = st.sidebar.radio(
    "Choose Pipeline Mode:", ["INTEGRATED", "STANDALONE"],
    index=0 if MODE == "INTEGRATED" else 1
)

st.sidebar.header(" Settings")
MODEL = st.sidebar.selectbox("Ollama Model", ["mistral", "llama3.2"])
# force_regen = st.sidebar.checkbox("Force Regenerate", value=FORCE_REGENERATE)

# Create directories
os.makedirs("data/input/SSDs", exist_ok=True)
os.makedirs("data/output/json_data", exist_ok=True)
os.makedirs("data/output/alltestcases", exist_ok=True)
os.makedirs("data/output/testcases", exist_ok=True)

# MAIN TABS
tab1, tab2, tab3 = st.tabs([" Upload", " Run Mode", "Results"])

# ===== TAB 1: UPLOAD FILES =====
with tab1:
    st.header("File Upload")
    
    if selected_mode == "INTEGRATED":
        st.info("INTEGRATED MODE : Upload SSD DOCX → Run Mode")
        uploaded_ssd = st.file_uploader("Upload SSD DOCX", type=['docx'], key="ssd_integrated")
        if uploaded_ssd:
            filepath = f"data/input/SSDs/{uploaded_ssd.name}"
            with open(filepath, "wb") as f:
                f.write(uploaded_ssd.getbuffer())
            st.session_state.ssd_path = filepath
            st.success(f"SSD saved: {uploaded_ssd.name}")
    
    # else:  # STANDALONE
    #     st.info("**STANDALONE MODE**: Upload SSD DOCX + TestCases TXT")
    #     col1, col2 = st.columns(2)
    #     with col1:
    #         uploaded_json = st.file_uploader("SSD JSON", type=['docx'], key="ssd_json")
    #     with col2:
    #         uploaded_txt = st.file_uploader("TestCases TXT", type=['txt'], key="testcases_txt")
        
    #     if uploaded_json and uploaded_txt:
    #         json_path = f"data/input/SSDs/{uploaded_json.name}"
    #         txt_path = f"data/input/SSDs/{uploaded_txt.name}"
    #         with open(json_path, "wb") as f:
    #             f.write(uploaded_json.getbuffer())
    #         with open(txt_path, "wb") as f:
    #             f.write(uploaded_txt.getbuffer())
    #         st.session_state.standalone_json = json_path
    #         st.session_state.standalone_txt = txt_path
    #         st.success("Files ready for validation!")

    else:  # STANDALONE
        st.info(" STANDALONE MODE : Upload SSD and TestCases")
        col1, col2 = st.columns(2)
        with col1:
            uploaded_docx = st.file_uploader(" SSD DOCX", type=['docx'], key="ssd_docx")
        with col2:
            uploaded_txt = st.file_uploader(" TestCases TXT", type=['txt'], key="testcases_txt")
    
        if uploaded_docx and uploaded_txt:
        # Save files
            docx_path = f"data/input/SSDs/{uploaded_docx.name}"
            txt_path = f"data/input/SSDs/{uploaded_txt.name}"
            with open(docx_path, "wb") as f:
                f.write(uploaded_docx.getbuffer())
            with open(txt_path, "wb") as f:
                f.write(uploaded_txt.getbuffer())
        
            st.session_state.standalone_docx = docx_path
            st.session_state.standalone_txt = txt_path
            st.success("Files ready! Will process DOCX → JSON → Validate")



# ===== TAB 2: RUN PIPELINE =====
# with tab2:
#     st.header("Run Mode")
    
#     if selected_mode == "INTEGRATED":
#         st.info("INTEGRATED MODE : SSD → Extract → Classify → Generate → Validate → Feedback")
        
#         if st.button("Generate Testcases", type="secondary", use_container_width=True):
#             if 'ssd_path' not in st.session_state:
#                 st.error("Upload SSD first!")
#             else:
#                 with st.spinner("Running FULL pipeline..."):
#                     try:
#                         # 1. Extract
#                         ssd_path = st.session_state.ssd_path
#                         raw_data = extract_docx_sections(ssd_path)
#                         json_path = f"data/output/{Path(ssd_path).stem}_structured.json"
#                         with open(json_path, 'w', encoding='utf-8') as f:
#                             json.dump(raw_data, f, indent=2)
                        
#                         # 2. Classify
#                         classified = aggregate_important_requirements(raw_data)
#                         classified_path = PROCESSED_SSD_FILE
#                         classified_path.parent.mkdir(exist_ok=True)
#                         with open(classified_path, 'w', encoding='utf-8') as f:
#                             json.dump(classified, f, indent=2)
                        
#                         # 3. Generate
#                         GENERATED_TESTCASES_FILE.parent.mkdir(exist_ok=True)
#                         run_generator(
#                             master_requirement_file=classified_path,
#                             new_requirement_file=None,
#                             output_testcase_file=GENERATED_TESTCASES_FILE,
#                             hash_file=Path("data/output/requirements.hash")
#                         )
                        
#                         # 4. FIXED: Validate + Feedback (Handle 6 return values)
#                         for attempt in range(3):
#                             result = validate_testcases(
#                                 requirement_file=classified_path,
#                                 testcase_file=GENERATED_TESTCASES_FILE
#                             )
                            
#                             #  SAFE UNPACKING
#                             if result and len(result) >= 4:
#                                 coverage, missing, completeness, accuracy, *_ = result
#                                 col1, col2 = st.columns(2)
#                                 col1.metric("Completeness", f"{completeness:.1f}%")
#                                 col2.metric("Accuracy", f"{accuracy:.1f}%")
                                
#                                 if completeness >= 100 or not missing:
#                                     st.success(" Validation passed!")
#                                     break
                                
#                                 if missing:
#                                     # Regenerate missing
#                                     missing_json = Path("data/output/new_requirements.json")
#                                     grouped_missing = {}
#                                     for item in missing:
#                                         cat = item.get("category", "General") if isinstance(item, dict) else "General"
#                                         req_text = item.get("text", str(item)) if isinstance(item, dict) else str(item)
#                                         grouped_missing.setdefault(cat, []).append(req_text)
                                    
#                                     missing_json.parent.mkdir(exist_ok=True)
#                                     with open(missing_json, 'w', encoding='utf-8') as f:
#                                         json.dump(grouped_missing, f, indent=2)
                                    
#                                     run_generator(
#                                         master_requirement_file=classified_path,
#                                         new_requirement_file=missing_json,
#                                         output_testcase_file=GENERATED_TESTCASES_FILE,
#                                         hash_file=Path("data/output/requirements.hash")
#                                     )
#                             else:
#                                 st.error(" Validation failed!")
#                                 break
                        
#                         st.balloons()
#                         st.success(" FULL PIPELINE COMPLETE!")
                        
#                     except Exception as e:
#                         st.error(f" Pipeline failed: {str(e)}")
    
#     else:  # STANDALONE
#         st.info("STANDALONE MODE : DOCX → Extract → Classify → Validate")
#         if st.button(" Validate Testcases", type="secondary", use_container_width=True):
#             if 'standalone_docx' not in st.session_state or 'standalone_txt' not in st.session_state:
#                 st.error(" Upload SSD DOCX + TestCases TXT first!")
#             else:
#                 with st.spinner(" Validate Testcases"):
#                  try:
#                     # 1. EXTRACT DOCX → JSON
#                         from data_processing.raw_extraction import extract_docx_sections
#                         from data_processing.data_classification import aggregate_important_requirements
#                         from config import PROCESSED_SSD_FILE
                    
#                         docx_path = st.session_state.standalone_docx
#                         txt_path = st.session_state.standalone_txt
                    
#                         # st.info(" Step 1: Extracting DOCX...")
#                         raw_data = extract_docx_sections(docx_path)
                    
#                         # st.info(" Step 2: Classifying requirements...")
#                         classified_data = aggregate_important_requirements(raw_data)
                    
#                     # Save classified JSON
#                         PROCESSED_SSD_FILE.parent.mkdir(parents=True, exist_ok=True)
#                         with open(PROCESSED_SSD_FILE, 'w', encoding='utf-8') as f:
#                             json.dump(classified_data, f, indent=2, ensure_ascii=False)
                
#                         # st.success(f" Classified JSON saved: {PROCESSED_SSD_FILE}")
                    
#                     # 3. VALIDATE
#                         # st.info(" Step 3: Validating test cases...")
#                         result = validate_testcases(
#                             requirement_file=PROCESSED_SSD_FILE,
#                             testcase_file=Path(txt_path)
#                         )
                    
#                         if result and len(result) >= 4:
#                             coverage, missing, completeness, accuracy, prioritized, xlsx_path = result
#                             col1, col2 = st.columns(2)
#                             col1.metric(" Completeness", f"{completeness:.1f}%")
#                             col2.metric(" Accuracy", f"{accuracy:.1f}%")
                        
#                             st.success(f" STANDALONE COMPLETE!  [Excel]({xlsx_path})")
                        
#                         # Show top prioritized test cases
#                             if prioritized:
#                                 st.subheader(" Top 10 Prioritized Test Cases")
#                                 df_show = pd.DataFrame([
#                                     {'ID': tc.get('id'), 'Priority': tc['priority'], 
#                                      'Type': tc['testcases distribution'], 
#                                      'Score': f"{tc['priority_score']:.1%}", 
#                                      'User Story': tc['userstory'][:80] + '...'}
#                                     for tc in prioritized[:10]
#                                 ])
#                                 st.dataframe(df_show, use_container_width=True)
                        
#                         # Downloads
#                             if xlsx_path and Path(xlsx_path).exists():
#                                 with open(xlsx_path, "rb") as f:
#                                     st.download_button(" Download Prioritized Excel", 
#                                                      f.read(), "testcases_prioritized.xlsx")
                    
#                  except Exception as e:
#                         st.error(f" Pipeline failed: {str(e)}")
#                         st.exception(e)



# with tab2:
#     st.header("Run Mode")
    
#     if selected_mode == "INTEGRATED":
#         st.info("INTEGRATED MODE : SSD → Extract → Classify → Generate → Validate → Feedback")
        
#         if st.button("Generate Testcases", type="secondary", use_container_width=True):
#             if 'ssd_path' not in st.session_state:
#                 st.error("Upload SSD first!")
#             else:
#                 with st.spinner("Running FULL pipeline..."):
#                     try:
#                         # 1. Extract
#                         ssd_path = st.session_state.ssd_path
#                         raw_data = extract_docx_sections(ssd_path)
#                         json_path = f"data/output/{Path(ssd_path).stem}_structured.json"
#                         with open(json_path, 'w', encoding='utf-8') as f:
#                             json.dump(raw_data, f, indent=2)
                        
#                         # 2. Classify
#                         classified = aggregate_important_requirements(raw_data)
#                         classified_path = PROCESSED_SSD_FILE
#                         classified_path.parent.mkdir(exist_ok=True)
#                         with open(classified_path, 'w', encoding='utf-8') as f:
#                             json.dump(classified, f, indent=2)
                        
#                         # 3. Generate
#                         GENERATED_TESTCASES_FILE.parent.mkdir(exist_ok=True)
#                         run_generator(
#                             master_requirement_file=classified_path,
#                             new_requirement_file=None,
#                             output_testcase_file=GENERATED_TESTCASES_FILE,
#                             hash_file=Path("data/output/requirements.hash")
#                         )
                        
#                         # 4. FIXED: Validate + Feedback (Handle 6 return values)
#                         for attempt in range(3):
#                             result = validate_testcases(
#                                 requirement_file=classified_path,
#                                 testcase_file=GENERATED_TESTCASES_FILE
#                             )
                            
#                             # SAFE UNPACKING
#                             if result and len(result) >= 4:
#                                 coverage, missing, completeness, accuracy, *_ = result
#                                 col1, col2 = st.columns(2)
#                                 col1.metric("Completeness", f"{completeness:.1f}%")
#                                 col2.metric("Accuracy", f"{accuracy:.1f}%")
                                
#                                 if completeness >= 100 or not missing:
#                                     st.success("Validation passed!")
#                                     break
                                
#                                 if missing:
#                                     # Show missing requirements
#                                     st.warning(f"Missing {len(missing)} requirements - Attempt {attempt+1}/3")
#                                     st.subheader("Missing Requirements:")
#                                     for i, req in enumerate(missing[:10], 1):
#                                         st.write(f"{i}. {req[:100]}...")
                                    
#                                     # Regenerate missing
#                                     missing_json = Path("data/output/new_requirements.json")
#                                     grouped_missing = {}
#                                     for item in missing:
#                                         cat = item.get("category", "General") if isinstance(item, dict) else "General"
#                                         req_text = item.get("text", str(item)) if isinstance(item, dict) else str(item)
#                                         grouped_missing.setdefault(cat, []).append(req_text)
                                    
#                                     missing_json.parent.mkdir(exist_ok=True)
#                                     with open(missing_json, 'w', encoding='utf-8') as f:
#                                         json.dump(grouped_missing, f, indent=2)
                                    
#                                     run_generator(
#                                         master_requirement_file=classified_path,
#                                         new_requirement_file=missing_json,
#                                         output_testcase_file=GENERATED_TESTCASES_FILE,
#                                         hash_file=Path("data/output/requirements.hash")
#                                     )
#                             else:
#                                 st.error("Validation failed!")
#                                 break
                        
#                         st.balloons()
#                         st.success("FULL PIPELINE COMPLETE!")
                        
#                     except Exception as e:
#                         st.error(f"Pipeline failed: {str(e)}")
    
#     else:  # STANDALONE
#         st.info("STANDALONE MODE : DOCX → Extract → Classify → Validate")
#         if st.button("Validate Testcases", type="secondary", use_container_width=True):
#             if 'standalone_docx' not in st.session_state or 'standalone_txt' not in st.session_state:
#                 st.error("Upload SSD DOCX + TestCases TXT first!")
#             else:
#                 with st.spinner("Validate Testcases"):
#                     try:
#                         # 1. EXTRACT DOCX → JSON
#                         from data_processing.raw_extraction import extract_docx_sections
#                         from data_processing.data_classification import aggregate_important_requirements
#                         from config import PROCESSED_SSD_FILE
                        
#                         docx_path = st.session_state.standalone_docx
#                         txt_path = st.session_state.standalone_txt
                        
#                         # st.info("Step 1: Extracting DOCX...")
#                         raw_data = extract_docx_sections(docx_path)
                        
#                         # st.info("Step 2: Classifying requirements...")
#                         classified_data = aggregate_important_requirements(raw_data)
                        
#                         # Save classified JSON
#                         PROCESSED_SSD_FILE.parent.mkdir(parents=True, exist_ok=True)
#                         with open(PROCESSED_SSD_FILE, 'w', encoding='utf-8') as f:
#                             json.dump(classified_data, f, indent=2, ensure_ascii=False)
                        
#                         # st.success(f"Classified JSON saved: {PROCESSED_SSD_FILE}")
                        
#                         # 3. VALIDATE
#                         # st.info("Step 3: Validating test cases...")
#                         result = validate_testcases(
#                             requirement_file=PROCESSED_SSD_FILE,
#                             testcase_file=Path(txt_path)
#                         )
                        
#                         if result and len(result) >= 4:
#                             coverage, missing, completeness, accuracy, prioritized, xlsx_path = result
#                             col1, col2 = st.columns(2)
#                             col1.metric("Completeness", f"{completeness:.1f}%")
#                             col2.metric("Accuracy", f"{accuracy:.1f}%")
                            
#                             st.success(f"STANDALONE COMPLETE! [Excel]({xlsx_path})")
                            
#                             # Show missing requirements if any
#                             if missing:
#                                 st.warning(f"Missing {len(missing)} requirements")
#                                 st.subheader("Missing Requirements:")
#                                 for i, req in enumerate(missing[:10], 1):
#                                     st.write(f"{i}. {req[:100]}...")
                            
#                             # Show top prioritized test cases
#                             if prioritized:
#                                 st.subheader("Top 10 Prioritized Test Cases")
#                                 df_show = pd.DataFrame([
#                                     {'ID': tc.get('id'), 'Priority': tc['priority'], 
#                                      'Type': tc['testcases distribution'], 
#                                      'Score': f"{tc['priority_score']:.1%}", 
#                                      'User Story': tc['userstory'][:80] + '...'}
#                                     for tc in prioritized[:10]
#                                 ])
#                                 st.dataframe(df_show, use_container_width=True)
                            
#                             # Downloads
#                             if xlsx_path and Path(xlsx_path).exists():
#                                 with open(xlsx_path, "rb") as f:
#                                     st.download_button("Download Prioritized Excel", 
#                                                      f.read(), "testcases_prioritized.xlsx")
                        
#                     except Exception as e:
#                         st.error(f"Pipeline failed: {str(e)}")
#                         st.exception(e)


#new tab2

with tab2:
    st.header("Run Mode")
    
    if selected_mode == "INTEGRATED":
        st.info("INTEGRATED MODE : SSD → Extract → Classify → Generate → Validate → Feedback")
        
        if st.button("Generate Testcases", type="secondary", use_container_width=True):
            if 'ssd_path' not in st.session_state:
                st.error("Upload SSD first!")
            else:
                with st.spinner("Running FULL pipeline..."):
                    try:
                        # 1. Extract
                        ssd_path = st.session_state.ssd_path
                        raw_data = extract_docx_sections(ssd_path)
                        json_path = f"data/output/{Path(ssd_path).stem}_structured.json"
                        with open(json_path, 'w', encoding='utf-8') as f:
                            json.dump(raw_data, f, indent=2)
                        
                        # 2. Classify
                        classified = aggregate_important_requirements(raw_data)
                        classified_path = PROCESSED_SSD_FILE
                        classified_path.parent.mkdir(exist_ok=True)
                        with open(classified_path, 'w', encoding='utf-8') as f:
                            json.dump(classified, f, indent=2)
                        
                        # 3. Generate
                        GENERATED_TESTCASES_FILE.parent.mkdir(exist_ok=True)
                        run_generator(
                            master_requirement_file=classified_path,
                            new_requirement_file=None,
                            output_testcase_file=GENERATED_TESTCASES_FILE,
                            hash_file=Path("data/output/requirements.hash")
                        )
                        
                        # 4. FIXED: Validate + Feedback (Handle 6 return values)
                        for attempt in range(3):
                            result = validate_testcases(
                                requirement_file=classified_path,
                                testcase_file=GENERATED_TESTCASES_FILE
                            )
                            
                            # SAFE UNPACKING
                            if result and len(result) >= 4:
                                coverage, missing, completeness, accuracy, *_ = result
                                col1, col2 = st.columns(2)
                                col1.metric("Completeness", f"{completeness:.1f}%")
                                col2.metric("Accuracy", f"{accuracy:.1f}%")
                                
                                if completeness >= 100 or not missing:
                                    st.success("Validation passed!")
                                    break
                                
                                if missing:
                                    # FIXED: Safe string extraction + slicing
                                    # st.warning(f"Missing {len(missing)} requirements - Attempt {attempt+1}/3")
                                    # st.subheader("Missing Requirements:")
                                    
                                    # for i, req in enumerate(missing[:10], 1):
                                    #     # SAFE STRING EXTRACTION
                                    #     req_text = str(req).strip()
                                    #     if len(req_text) > 100:
                                    #         req_text = req_text[:100] + "..."
                                    #     st.write(f"{i}. {req_text}")
                                    
                                    # Regenerate missing - FIXED safe extraction
                                    missing_json = Path("data/output/new_requirements.json")
                                    grouped_missing = {}
                                    for item in missing:
                                        # SAFE EXTRACTION
                                        req_text = str(item).strip()
                                        if len(req_text) < 10:
                                            continue
                                        cat = "General"  # Default category
                                        grouped_missing.setdefault(cat, []).append(req_text)
                                    
                                    missing_json.parent.mkdir(exist_ok=True)
                                    with open(missing_json, 'w', encoding='utf-8') as f:
                                        json.dump(grouped_missing, f, indent=2)
                                    
                                    run_generator(
                                        master_requirement_file=classified_path,
                                        new_requirement_file=missing_json,
                                        output_testcase_file=GENERATED_TESTCASES_FILE,
                                        hash_file=Path("data/output/requirements.hash")
                                    )
                            else:
                                st.error("Validation failed!")
                                break
                        
                        st.balloons()
                        st.success("FULL PIPELINE COMPLETE!")
                        
                    except Exception as e:
                        st.error(f"Pipeline failed: {str(e)}")
    
    else:  # STANDALONE
        st.info("STANDALONE MODE : DOCX → Extract → Classify → Validate")
        if st.button("Validate Testcases", type="secondary", use_container_width=True):
            if 'standalone_docx' not in st.session_state or 'standalone_txt' not in st.session_state:
                st.error("Upload SSD DOCX + TestCases TXT first!")
            else:
                with st.spinner("Validate Testcases"):
                    try:
                        # 1. EXTRACT DOCX → JSON
                        from data_processing.raw_extraction import extract_docx_sections
                        from data_processing.data_classification import aggregate_important_requirements
                        from config import PROCESSED_SSD_FILE
                        
                        docx_path = st.session_state.standalone_docx
                        txt_path = st.session_state.standalone_txt
                        
                        raw_data = extract_docx_sections(docx_path)
                        classified_data = aggregate_important_requirements(raw_data)
                        
                        # Save classified JSON
                        PROCESSED_SSD_FILE.parent.mkdir(parents=True, exist_ok=True)
                        with open(PROCESSED_SSD_FILE, 'w', encoding='utf-8') as f:
                            json.dump(classified_data, f, indent=2, ensure_ascii=False)
                        
                        # 3. VALIDATE
                        result = validate_testcases(
                            requirement_file=PROCESSED_SSD_FILE,
                            testcase_file=Path(txt_path)
                        )
                        
                        if result and len(result) >= 4:
                            coverage, missing, completeness, accuracy, prioritized, xlsx_path = result
                            col1, col2 = st.columns(2)
                            col1.metric("Completeness", f"{completeness:.1f}%")
                            col2.metric("Accuracy", f"{accuracy:.1f}%")
                            
                            st.success(f"STANDALONE COMPLETE! [Excel]({xlsx_path})")
                            
                            # FIXED: Safe missing requirements display
                            if missing:
                                st.warning(f"Missing {len(missing)} requirements")
                                st.subheader("Missing Requirements:")
                                for i, req in enumerate(missing[:], 1):
                                    # SAFE STRING EXTRACTION
                                    req_text = str(req).strip()
                                    if len(req_text) > 100:
                                        req_text = req_text[:100] + "..."
                                    st.write(f"{i}. {req_text}")
                            
                            # Show top prioritized test cases
                            if prioritized:
                                st.subheader("Top 10 Prioritized Test Cases")
                                df_show = pd.DataFrame([
                                    {'ID': tc.get('id'), 'Priority': tc['priority'], 
                                     'Type': tc['testcases distribution'], 
                                    #  'Score': f"{tc['priority_score']:.1%}", 
                                     'User Story': str(tc['userstory'])[:80] + '...' if len(str(tc['userstory'])) > 80 else str(tc['userstory'])}
                                    for tc in prioritized[:10]
                                ])
                                st.dataframe(df_show, use_container_width=True)
                            
                            # Downloads
                            if xlsx_path and Path(xlsx_path).exists():
                                with open(xlsx_path, "rb") as f:
                                    st.download_button("Download Prioritized Excel", 
                                                     f.read(), "testcases_prioritized.xlsx")
                        
                    except Exception as e:
                        st.error(f"Pipeline failed: {str(e)}")
                        st.exception(e)




# ===== TAB 3: RESULTS =====
with tab3:
    st.header("Results Dashboard")
    col1, col2, col3, col4 = st.columns(4)
    
    ssd_count = len(list(Path("data/input/SSDs").glob("*.docx")))
    json_count = len(list(Path("data/output").glob("**/*.json")))
    testcase_file = GENERATED_TESTCASES_FILE
    testcase_lines = 0
    if testcase_file.exists():
        testcase_lines = len(testcase_file.read_text().splitlines())
    
    col1.metric("SSDs", ssd_count)
    col2.metric("JSONs", json_count)
    col3.metric("Test Cases", testcase_lines)
    col4.metric("Status", "Complete" if testcase_file.exists() else "Pending")
    
    # FIXED Preview test cases
    if testcase_file.exists():
        st.subheader("Generated Test Cases Preview")
        with open(testcase_file) as f:
            content = f.read()
        st.text_area("Preview", content, height=300, label_visibility="collapsed")
        st.download_button("Download TestCases.txt", data=content, file_name="testcases.txt")

# ===== TAB 4: LOGS =====
# with tab4:
#     st.header(" Folder Structure")
#     st.code("""
# TestCases_G_V/
# ├── config.py                 Your config
# ├── data/
# │   ├── input/SSDs/           DOCX uploads (Integrated)
# │   │   └── your_ssd.docx
# │   ├── output/json_data/
# │   │   ├── classified_file.json
# │   │   └── new_requirements.json
# │   ├── output/alltestcases/
# │   │   └── testcases.txt     Generator output
# │   └── output/testcases/
# │       └── testcases.xlsx    Validator output
# ├── data_processing/
# ├── generator/
# ├── validator/
# └── main_app.py               This UI
#     """)

# Footer
st.markdown("---")
# st.markdown("*Production-ready TestCase AI Pipeline | INTEGRATED & STANDALONE modes*")
