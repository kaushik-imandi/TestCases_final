# #!/usr/bin/env python3
# """
# User Story Generator - Single File CLI
# Usage: python user_story_generator.py requirements.json
# Output: user_stories.xlsx + hash.txt + updated_requirements.json
# """

# import json
# import sys
# import hashlib
# from pathlib import Path
# import pandas as pd
# from openpyxl.styles import Font, PatternFill
# import argparse

# def load_json(path: Path):
#     if path.exists():
#         try:
#             data = path.read_text(encoding="utf-8").strip()
#             if not data:
#                 return {}
#             return json.loads(data)
#         except json.JSONDecodeError:
#             print(f"Warning: {path} contains invalid JSON. Using empty dict.")
#             return {}
#     return {}

# def compute_hash(data):
#     return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

# def save_json(path: Path, data):
#     path.write_text(json.dumps(data, indent=2), encoding="utf-8")

# def save_hash(path: Path, hash_value):
#     path.write_text(hash_value, encoding="utf-8")

# def generate_user_story(requirement: str, section: str, counter: list[int]) -> str:
#     text = requirement.strip()
#     if len(text) < 20 or "BRD" in text or "test" in text.lower():
#         return None
    
#     us_id = f"US_{counter[0]:02d}"
#     counter[0] += 1
#     return f"{us_id} {section} {text}"

# def main(input_file: Path):
#     print(" User Story Generator")
#     print(f" Input: {input_file}")
    
#     # Files
#     output_xlsx = input_file.with_suffix('.xlsx').with_stem(input_file.stem + '_user_stories')
#     hash_file = input_file.with_suffix('.txt').with_stem(input_file.stem + '_hash')
#     updated_file = input_file.with_suffix('.json').with_stem(input_file.stem + '_updated')
    
#     # Load requirements
#     requirements = load_json(input_file)
#     if not requirements:
#         print(" No requirements found!")
#         return 1
    
#     print(f" Found {sum(len(reqs) for reqs in requirements.values())} requirements")
    
#     # Generate user stories
#     user_stories = []
#     counter = [1]
    
#     for section, reqs in requirements.items():
#         print(f"   {section}: {len(reqs)} reqs")
#         for req in reqs:
#             story = generate_user_story(req, section, counter)
#             if story:
#                 user_stories.append(story)
    
#     if not user_stories:
#         print("No valid user stories generated!")
#         return 1
    
#     # Create Excel
#     df_data = []
#     for story in user_stories:
#         parts = story.split(" ", 2)
#         if len(parts) == 3:
#             df_data.append({
#                 'ID': parts[0],
#                 'Section': parts[1],
#                 'User_Story': parts[2]
#             })
    
#     df = pd.DataFrame(df_data)
    
#     with pd.ExcelWriter(output_xlsx, engine='openpyxl') as writer:
#         df.to_excel(writer, sheet_name='User Stories', index=False)
#         ws = writer.sheets['User Stories']
        
#         # Headers
#         for cell in ws[1]:
#             cell.font = Font(bold=True, color="FFFFFF")
#             cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        
#         # Column widths
#         for col in ws.columns:
#             max_len = max(len(str(cell.value)) for cell in col if cell.value)
#             ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 80)
    
#     # Save files
#     save_json(updated_file, requirements)
#     save_hash(hash_file, compute_hash(requirements))
    
#     print(f"\n SUCCESS!")
#     print(f" {len(user_stories)} User Stories generated")
#     print(f" {output_xlsx}")
#     print(f" {updated_file}")
#     print(f" {hash_file}")
    
#     # Preview
#     print("\n PREVIEW:")
#     for story in user_stories[:3]:
#         print(f"  {story[:80]}...")
    
#     return 0

# if __name__ == "__main__":
#     parser = argparse.ArgumentParser(description="User Story Generator")
#     parser.add_argument('input_file', type=Path, help='Requirements JSON file')
#     args = parser.parse_args()
    
#     if not args.input_file.exists():
#         print(f" File not found: {args.input_file}")
#         sys.exit(1)
    
#     sys.exit(main(args.input_file))









#!/usr/bin/env python3
#last working userstories code

# import os
# import json
# import hashlib
# import argparse
# from pathlib import Path
# from langchain_ollama import ChatOllama
# from langchain_core.prompts import ChatPromptTemplate
# from langgraph.graph import StateGraph, END


# # -----------------------------
# # Setup model
# # -----------------------------

# print("Loading model...")
# llm = ChatOllama(model="mistral", temperature=0.2)


# # -----------------------------
# # Prompt template for user stories
# # -----------------------------

# USER_STORY_PROMPT = """
# You are a Requirements Engineer. Convert the given requirement text into Agile user stories.

# Generate user stories in this exact format, with **assending numbers** starting from US‑001:

# take below stories as reference

# User StoryUS‑001
# RequirementEnsure rescheduling changes do not break NPA/Risk processing
# Requirement DescriptionAs a risk team member, I want the rescheduling validation to work seamlessly with existing NPA classification and risk parameter rules so that compliance is unaffected.

# User StoryUS‑002
# RequirementRegeneration of repayment schedule after each eligible rescheduling event
# Requirement DescriptionAs a customer service representative, I want the system to re‑calculate EMI, tenure, and interest after each approved reschedule so that the new repayment plan reflects revised terms.

# User StoryUS‑003
# RequirementTrack and maintain audit trail of each rescheduling event
# Requirement DescriptionAs an audit/regulatory user, I want the system to store every rescheduling event in audit logs so that historical actions are fully traceable.

# User StoryUS‑004
# RequirementSystem validation for number of rescheduling events within 6 months
# Requirement DescriptionAs a loan servicing officer, I want the system to automatically validate whether the customer has remaining allowed rescheduling counts in the last 6 months so that compliant decisions are maintained.

# User StoryUS‑005
# RequirementIntroduction of configurable parameter Max_Reschedules_6M at product level
# Requirement DescriptionAs a system administrator, I want to configure the maximum number of loan rescheduling events permitted in a 6‑month window so that business teams can adjust rules without code changes.

# Rules:
# - Use format:
#   - "User StoryUS‑XXX" (e.g., US‑005, US‑004, ..., US‑001).
#   - "Requirement" line: short, imperative, business‑focused.
#   - "Requirement Description" line: "As a [role], I want ... so that ...".
# - Use only the provided requirement text; do not invent new features.
# - Do not add any extra text, explanations, or JSON.
# - Output only the user stories in the format above.

# Requirement text:
# {input_text}
# """


# # -----------------------------
# # State and graph
# # -----------------------------

# class State(dict):
#     text: str          # requirement text for this chunk
#     user_stories: str  # output from LLM


# def generate_user_stories_node(state: State):
#     print("Generating user stories...")
#     prompt = ChatPromptTemplate.from_template(USER_STORY_PROMPT)
#     chain = prompt | llm
#     result = chain.invoke({"input_text": state["text"]})
#     stories = result.content.strip()
#     print("\n" + stories)
#     state["user_stories"] = stories
#     return state


# graph = StateGraph(State)
# graph.add_node("generate", generate_user_stories_node)
# graph.set_entry_point("generate")
# graph.add_edge("generate", END)
# app = graph.compile()


# # -----------------------------
# # Read JSON file utility
# # -----------------------------

# def load_json(path: Path) -> dict:
#     if not path.exists():
#         raise FileNotFoundError(f"Requirement file not found: {path}")
#     try:
#         data_str = path.read_text(encoding="utf-8").strip()
#         if not data_str:
#             return {}
#         return json.loads(data_str)
#     except json.JSONDecodeError as e:
#         raise ValueError(f"Invalid JSON in {path}: {e}")


# # -----------------------------
# # Flatten JSON into a single text block
# # -----------------------------

# def json_to_requirement_text(data: dict) -> str:
#     parts = []

#     if "document_name" in data:
#         parts.append(f"Document: {data['document_name']}")

#     if "sections" in data:
#         for sec in data["sections"]:
#             title = f"{sec.get('feature', '')} – {sec.get('sub_section', '')}"
#             content = "\n".join(sec.get("content", [])).strip()
#             if content:
#                 parts.append(f"\n### {title}\n{content}")

#     return "\n\n".join(parts)


# # -----------------------------
# # Hash utilities (optional)
# # -----------------------------

# def compute_hash(data) -> str:
#     return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()


# def save_hash(path: Path, hash_value: str):
#     path.write_text(hash_value, encoding="utf-8")


# # -----------------------------
# # CLI entry point
# # -----------------------------

# def main():
#     parser = argparse.ArgumentParser(
#         description="Generate user stories from a requirements JSON file using Ollama Mistral."
#     )
#     parser.add_argument(
#         "input_file",
#         type=Path,
#         help="Path to your requirements JSON file (e.g., requirements.json)"
#     )
#     parser.add_argument(
#         "--output",
#         type=Path,
#         default=Path("user_stories_output.txt"),
#         help="Path to save user stories output (default: user_stories_output.txt)"
#     )
#     parser.add_argument(
#         "--hash-file",
#         type=Path,
#         default=Path("requirements.hash"),
#         help="Hash file to track requirement changes (default: requirements.hash)"
#     )
#     args = parser.parse_args()

#     # Load JSON
#     data = load_json(args.input_file)

#     # Build requirement text
#     req_text = json_to_requirement_text(data)

#     # Compute hash
#     h = compute_hash(data)

#     # Check if already done
#     if args.hash_file.exists():
#         old_hash = args.hash_file.read_text(encoding="utf-8").strip()
#         if old_hash == h:
#             print("No changes in requirements; skipping regeneration.")
#             if args.output.exists():
#                 print("Output already exists. To regenerate, change the requirements or delete the hash file.")
#             return

#     # Send to graph
#     result = app.invoke({
#         "text": req_text,
#         "user_stories": "",
#     })

#     stories = result.get("user_stories", "")

#     if stories:
#         # Print
#         print("\n" + "=" * 60)
#         print("USER STORIES (OUTPUT)")
#         print("=" * )
#         print(stories)

#         # Save to file
#         with args.output.open("w", encoding="utf-8") as f:
#             f.write(stories)

#         print(f"\nUser stories saved to: {args.output}")
#         save_hash(args.hash_file, h)
#     else:
#         print("No user stories generated. Check Ollama + model and input.")


# if __name__ == "__main__":
#     main()



















# import json
# import os
# import hashlib
# from pathlib import Path
# from langchain_ollama import ChatOllama
# from langchain_core.prompts import ChatPromptTemplate
# from langgraph.graph import StateGraph, END
# # from config import FORCE_REGENERATE


# FORCE_REGENERATE=False

# print("Loading model...")
# llm = ChatOllama(model="mistral", temperature=0.2)

# # Utility Functions (UNCHANGED)
# def load_json(path: Path):
#     if path.exists():
#         try:
#             data = path.read_text(encoding="utf-8").strip()
#             if not data:
#                 return {}
#             return json.loads(data)
#         except json.JSONDecodeError:
#             print(f"Warning: {path} contains invalid JSON. Using empty dict instead.")
#             return {}
#     return {}

# def save_json(path: Path, data):
#     path.write_text(json.dumps(data, indent=2), encoding="utf-8")

# def compute_hash(data):
#     return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

# def load_hash(path: Path):
#     if path.exists():
#         return path.read_text(encoding="utf-8").strip()
#     return None

# def save_hash(path: Path, hash_value):
#     path.write_text(hash_value, encoding="utf-8")

# # Validator function (REPLACE with your actual validator)
# def get_priority_from_validator(test_case: str) -> str:
#     """Call your validator here. Returns 'High', 'Medium', or 'Low'"""
#     test_lower = test_case.lower()
#     if any(word in test_lower for word in ['error', 'block', 'security', 'invalid']):
#         return "High"
#     elif any(word in test_lower for word in ['boundary', 'edge', 'limit', 'max']):
#         return "Medium"
#     else:
#         return "Low"

# # ✅ FIXED: State class MOVED BEFORE node function
# class State(dict):
#     section: str
#     text: str
#     structured_testcases: list

# # ✅ NOW WORKS: Node function after State class
# def generate_structured_testcases_node(state: State):
#     print(f"Generating structured test cases for section: {state['section']}")
#     prompt = ChatPromptTemplate.from_template("""
# You are a Quality Assurance Engineer. Generate **structured JSON** for the requirement.

# Guidelines:
# 1. Break into 2-5 User Stories (US_001 format)
# 2. Each User Story gets 1-3 test cases covering Positive/Negative/Boundary
# 3. Output ONLY valid JSON array - NO extra text/markdown
# 4. Keep test cases concise

# Exact JSON format:
# [
#   {{
#     "user_story_id": "US_001",
#     "user_story": "As [user], I want [feature] so that [benefit]",
#     "test_case": "Verify that [concise test case]",
#     "distribution": "Positive|Negative|Boundary"
#   }}
# ]

# Requirement:
# {input_text}
# """)
#     chain = prompt | llm
#     result = chain.invoke({"input_text": state["text"]})
    
#     try:
#         structured = json.loads(result.content.strip())
#         print(f"Generated {len(structured)} structured test cases")
#     except json.JSONDecodeError:
#         print("JSON parse failed, using empty list")
#         structured = []
    
#     # Apply validator priorities
#     for item in structured:
#         item["priority"] = get_priority_from_validator(item["test_case"])
    
#     state["structured_testcases"] = structured
#     return state

# # Graph setup
# graph = StateGraph(State)
# graph.add_node("generate", generate_structured_testcases_node)
# graph.set_entry_point("generate")
# graph.add_edge("generate", END)
# app = graph.compile()

# # Public entry function
# def run_generator(
#     master_requirement_file: Path,
#     new_requirement_file: Path | None,
#     output_testcase_file: Path,
#     hash_file: Path
# ):
#     stored_requirements = load_json(master_requirement_file)
#     new_requirements = load_json(new_requirement_file) if new_requirement_file else {}

#     generate_master = not output_testcase_file.exists() or FORCE_REGENERATE
#     generate_new = bool(new_requirements)

#     if not generate_master and not generate_new:
#         print("Nothing new to generate.")
#         return

#     all_structured = []
#     global_tc_counter = 1

#     all_reqs = stored_requirements.copy()
#     if generate_new:
#         all_reqs.update(new_requirements)

#     for section, requirements in all_reqs.items():
#         if not requirements:
#             continue
#         combined_text = "\n".join(requirements)
#         print(f"Processing section: {section}")
#         result = app.invoke({
#             "section": section,
#             "text": combined_text,
#             "structured_testcases": []
#         })
        
#         for item in result["structured_testcases"]:
#             item["test_case_id"] = f"TC_{global_tc_counter:03d}"
#             item["section"] = section
#             global_tc_counter += 1
#             all_structured.append(item)

#     save_json(output_testcase_file, all_structured)
    
#     if generate_new:
#         for section, requirements in new_requirements.items():
#             stored_requirements.setdefault(section, [])
#             for req in requirements:
#                 if req not in stored_requirements[section]:
#                     stored_requirements[section].append(req)

#     save_json(master_requirement_file, stored_requirements)
#     save_hash(hash_file, compute_hash(stored_requirements))

#     if new_requirement_file:
#         save_json(new_requirement_file, {})

#     print(f"✅ Generated {len(all_structured)} structured test cases with priorities in {output_testcase_file}")

# if __name__ == "__main__":
#     from sys import argv
#     if len(argv) < 2:
#         print("Usage: python us_generator.py <classified_file.json>")
#         exit(1)
    
#     master_file = Path(argv[1])
#     output_file = master_file.with_name("testcases.json")
#     hash_file = master_file.with_name("hash.txt")
    
#     run_generator(master_file, None, output_file, hash_file)








import json
import os
import hashlib
from pathlib import Path
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END

FORCE_REGENERATE = False

print("Loading model...")
llm = ChatOllama(model="mistral", temperature=0.2)

# Utility Functions (UNCHANGED)
def load_json(path: Path):
    if path.exists():
        try:
            data = path.read_text(encoding="utf-8").strip()
            if not data:
                return {}
            return json.loads(data)
        except json.JSONDecodeError:
            print(f"Warning: {path} contains invalid JSON. Using empty dict instead.")
            return {}
    return {}

def save_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def compute_hash(data):
    return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

def load_hash(path: Path):
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return None

def save_hash(path: Path, hash_value):
    path.write_text(hash_value, encoding="utf-8")

# REMOVED: No more validator function - LLM handles priority

class State(dict):
    section: str
    text: str
    structured_testcases: list
    us_counter: int = 1

def generate_structured_testcases_node(state: State):
    print(f"Generating structured test cases for section: {state['section']}")
    
    # ✅ UPDATED PROMPT: LLM generates priority too
    prompt = ChatPromptTemplate.from_template("""
You are a Quality Assurance Engineer. Generate structured JSON test cases for this requirement section.

CRITICAL RULES:
1. Create 3-6 MINIMAL User Stories covering ALL requirements from ALL sections combined
2. DONT MISS ANY REQUIREMENT - cover every point mentioned
3. CONTINUOUS US NUMBERING: Use previous section UC numbers's ext_number and increment sequentially
4. Each US gets 3-5 test cases: Positive/Negative/Boundary + Edge cases
5. Complete ONE US fully before next - group all test cases under same US_ID
6. Same US_ID = IDENTICAL user_story text across all its test cases
7. distribution: ONLY "Positive", "Negative", or "Boundary" 
8. priority: ONLY "High", "Medium", or "Low"

EXAMPLE FORMAT (3 US, multiple TCs each):
[
 {{
    "user_story_id": "US_001",
    "user_story": "Introduction and Replacement of Promo Codes for Fund-In and Fund-Out Transactions in CBS from Cordys....",
    "test_case": "Verify the new promo code for transaction 1045",
    "distribution": "Positive",
    "priority": "High"
  }},
  {{
    "user_story_id": "US_001",
    "user_story": "Introduction and Replacement of Promo Codes for Fund-In and Fund-Out Transactions in CBS from Cordys...", 
    "test_case": "Verify the short description of the new promo code for transaction 1045 in English",
    "distribution": "Negative",
    "priority": "Medium"
  }},
  {{
    "user_story_id": "US_002",
    "user_story": "Additional Driver Age Validation.....",
    "test_case": "Verify that the additional  driver's age is above 18 year in the Auto lease- Additional Driver Screen",
    "distribution": "Positive",
    "priority": "Low"
  }},
  {{
    "user_story_id": "US_002",
    "user_story": "Additional Driver Age Validation.....",
    "test_case": "Verify that when driver's age is less than 18 years, then system show the error message "Applicant age is not in Range",
    "distribution": "Boundary",
    "priority": "High"
  }}
]

Requirement Section: {section_name}
Requirements:
{input_text}

Output ONLY valid JSON array following exact format above.
""")
    
    chain = prompt | llm
    result = chain.invoke({
        "input_text": state["text"],
        "section_name": state["section"]
    })
    
    try:
        structured = json.loads(result.content.strip())
        print(f"✅ Generated {len(structured)} structured test cases for {state['section']}")
    except json.JSONDecodeError as e:
        print(f"❌ JSON parse failed: {e}")
        print("Raw LLM output:", result.content[:500])
        structured = []
    
    # ✅ REMOVED: No more get_priority_from_validator() call - LLM handles it
    
    state["structured_testcases"] = structured
    return state

# Graph setup
graph = StateGraph(State)
graph.add_node("generate", generate_structured_testcases_node)
graph.set_entry_point("generate")
graph.add_edge("generate", END)
app = graph.compile()

def run_generator(
    master_requirement_file: Path,
    new_requirement_file: Path | None,
    output_testcase_file: Path,
    hash_file: Path
):
    stored_requirements = load_json(master_requirement_file)
    new_requirements = load_json(new_requirement_file) if new_requirement_file else {}

    generate_master = not output_testcase_file.exists() or FORCE_REGENERATE
    generate_new = bool(new_requirements)

    if not generate_master and not generate_new:
        print("Nothing new to generate.")
        return

    all_structured = []
    global_tc_counter = 1

    all_reqs = stored_requirements.copy()
    if generate_new:
        all_reqs.update(new_requirements)

    for section, requirements in all_reqs.items():
        if not requirements:
            continue
        combined_text = "\n".join(requirements)
        print(f"\n🔄 Processing section: {section}")
        
        result = app.invoke({
            "section": section,
            "text": combined_text,
            "structured_testcases": []
        })
        
        # ✅ FIXED: Validate US consistency within section
        section_tcs = result["structured_testcases"]
        us_dict = {}  # Track US_ID -> user_story mapping
        
        for item in section_tcs:
            # Ensure US consistency
            us_id = item["user_story_id"]
            if us_id not in us_dict:
                us_dict[us_id] = item["user_story"]
            else:
                # Fix inconsistent user_story text
                item["user_story"] = us_dict[us_id]
            
            item["test_case_id"] = f"TC_{global_tc_counter:03d}"
            item["section"] = section
            global_tc_counter += 1
            all_structured.append(item)

        print(f"   → Added {len(section_tcs)} TCs from {section} ({len(us_dict)} unique US)")

    save_json(output_testcase_file, all_structured)
    
    if generate_new:
        for section, requirements in new_requirements.items():
            stored_requirements.setdefault(section, [])
            for req in requirements:
                if req not in stored_requirements[section]:
                    stored_requirements[section].append(req)

    save_json(master_requirement_file, stored_requirements)
    save_hash(hash_file, compute_hash(stored_requirements))

    if new_requirement_file:
        save_json(new_requirement_file, {})

    print(f"\n✅ Generated {len(all_structured)} structured test cases with priorities in {output_testcase_file}")

if __name__ == "__main__":
    from sys import argv
    if len(argv) < 2:
        print("Usage: python us_generator.py <classified_file.json>")
        exit(1)
    
    master_file = Path(argv[1])
    output_file = master_file.with_name("testcases.json")
    hash_file = master_file.with_name("hash.txt")
    
    run_generator(master_file, None, output_file, hash_file)
