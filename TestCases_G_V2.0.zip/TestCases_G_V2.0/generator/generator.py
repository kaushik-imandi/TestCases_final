import json
import os
import hashlib
import re
from pathlib import Path
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END

# Import from config (add to your config.py if missing)
try:
    from config import GENERATED_TESTCASES_JSON
except ImportError:
    GENERATED_TESTCASES_JSON = Path("data/output/json_data/generated_testcases.json")

FORCE_REGENERATE = False

print("Loading Ollama model...")
llm = ChatOllama(model="mistral", temperature=0.2)

def load_json(path: Path):
    """Safely load JSON file"""
    if path.exists():
        try:
            data = path.read_text(encoding="utf-8").strip()
            if not data:
                return {}
            return json.loads(data)
        except json.JSONDecodeError as e:
            print(f"Warning: {path} invalid JSON: {e}")
            return {}
    return {}

def save_json(path: Path, data):
    """Safely save JSON file"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def compute_hash(data):
    """Compute hash for requirements"""
    return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

def save_hash(path: Path, hash_value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(hash_value, encoding="utf-8")

class State(dict):
    section: str
    text: str
    structured_testcases: list

def generate_structured_testcases_node(state: State):
    print(f"Generating test cases for section: {state['section']}")
    
    #  FIXED: DOUBLE CURLY BRACES {{}} for JSON examples
    prompt = ChatPromptTemplate.from_template("""
You are a QA Engineer. Generate test cases in EXACT JSON format.

RULES:
1. 3-6 User Stories covering ALL requirements
2. Each US: 3-5 test cases (Positive/Negative/Boundary)
3. Sequential IDs: US_001, US_002, TC_001, TC_002
4. distribution: ONLY "Positive", "Negative", "Boundary"
5. priority: ONLY "High", "Medium", "Low"

**EXACT JSON FORMAT** (copy structure):
[
  {{
    "user_story_id": "US_001",
    "user_story": "Introduction and Replacement of Promo Codes for Fund-In and Fund-Out Transactions in CBS from Cordys....",
    "test_case": "Verify promo code TC1045 applies correctly for fund-in",
    "distribution": "Positive",
    "priority": "High"
  }},
  {{
    "user_story_id": "US_001",
    "user_story": "Introduction and Replacement of Promo Codes for Fund-In and Fund-Out Transactions in CBS from Cordys...", 
    "test_case": "Verify the short description of the new promo code for transaction 1045 in English",
    "distribution": "Negative",
    "priority": "Medium"
  }},
  {{
    "user_story_id": "US_002",
    "user_story": "Additional Driver Age Validation.....m",
    "test_case": "Verify that the additional  driver's age is above 18 year in the Auto lease- Additional Driver Screen",
    "distribution": "Positive",
    "priority": "Low"
  }}
]

REQUIREMENTS:
Section: {section_name}
Text: {input_text}

Output ONLY valid JSON array matching format above. No explanations.
""")
    
    chain = prompt | llm
    result = chain.invoke({
        "input_text": state["text"],
        "section_name": state["section"]
    })
    
    # SAFE JSON parsing
    structured = []
    raw_content = result.content.strip()
    
    try:
        structured = json.loads(raw_content)
        if isinstance(structured, list):
            # Filter valid items only
            valid_items = []
            for item in structured:
                if (isinstance(item, dict) and 
                    all(k in item for k in ["user_story_id", "user_story", "test_case", "distribution", "priority"])):
                    valid_items.append(item)
            structured = valid_items
    except json.JSONDecodeError:
        # Fallback: extract JSON block
        json_match = re.search(r'\[.*\]', raw_content, re.DOTALL)
        if json_match:
            try:
                structured = json.loads(json_match.group())
            except:
                pass

    print(f"Generated {len(structured)} valid test cases")
    state["structured_testcases"] = structured
    return state

# LangGraph setup
graph = StateGraph(State)
graph.add_node("generate", generate_structured_testcases_node)
graph.set_entry_point("generate")
graph.add_edge("generate", END)
app = graph.compile()

def run_generator(
    master_requirement_file: Path,
    new_requirement_file: Path | None = None,
    output_testcase_file: Path = GENERATED_TESTCASES_JSON,
    hash_file: Path = Path("data/output/requirements.hash")
):
    print(" Test Case Generator STARTED")
    
    # Load requirements
    stored_requirements = load_json(master_requirement_file)
    new_requirements = load_json(new_requirement_file) if new_requirement_file else {}
    
    # Check if generation needed
    generate_master = not output_testcase_file.exists() or FORCE_REGENERATE
    generate_new = bool(new_requirements)
    
    if not generate_master and not generate_new:
        print("Nothing new to generate.")
        return
    
    #  FIXED: all_reqs properly defined
    all_reqs = stored_requirements.copy()
    if generate_new:
        all_reqs.update(new_requirements)
    
    all_structured = []
    global_tc_counter = 1
    
    for section, requirements in all_reqs.items():
        if not requirements:
            continue
            
        combined_text = "\n".join(requirements)
        print(f"\n Processing section: {section} ({len(requirements)} reqs)")
        
        result = app.invoke({
            "section": section,
            "text": combined_text,
            "structured_testcases": []
        })
        
        section_tcs = result["structured_testcases"]
        us_dict = {}  # Track consistent user stories
        
        for item_idx, item in enumerate(section_tcs):
            # SAFE type checking
            if not isinstance(item, dict):
                print(f" Skipping invalid item {item_idx}")
                continue
            
            # SAFE key access with defaults
            us_id = item.get("user_story_id", f"US_{len(us_dict)+1:03d}")
            user_story = item.get("user_story", f"User story for {section}")
            test_case = item.get("test_case", "Test case description")
            distribution = item.get("distribution", "positive").lower()
            priority = item.get("priority", "medium").lower()
            
            # Ensure US consistency
            if us_id not in us_dict:
                us_dict[us_id] = user_story
            else:
                user_story = us_dict[us_id]
            
            # Build safe item
            safe_item = {
                "user_story_id": us_id,
                "user_story": user_story[:200],  # Truncate long stories
                "test_case": test_case[:500],
                "distribution": distribution,
                "priority": priority,
                "test_case_id": f"TC_{global_tc_counter:03d}",
                "section": section
            }
            
            all_structured.append(safe_item)
            global_tc_counter += 1
    
        print(f"   Added {len([tc for tc in section_tcs if isinstance(tc, dict)])} TCs")
    
    # Save results
    save_json(output_testcase_file, all_structured)
    
    # Update master file if new requirements
    if generate_new:
        for section, requirements in new_requirements.items():
            stored_requirements.setdefault(section, [])
            for req in requirements:
                if req not in stored_requirements[section]:
                    stored_requirements[section].append(req)
        save_json(master_requirement_file, stored_requirements)
    
    # Save hash
    save_hash(hash_file, compute_hash(stored_requirements))
    
    if new_requirement_file and new_requirement_file.exists():
        save_json(new_requirement_file, {})  # Clear new requirements
    
    print(f"\n SUCCESS: Generated {len(all_structured)} test cases")
    print(f"Saved to: {output_testcase_file}")

if __name__ == "__main__":
    # Test standalone
    run_generator(
        master_requirement_file=Path("data/output/json_data/classified_file.json"),
        output_testcase_file=GENERATED_TESTCASES_JSON
    )