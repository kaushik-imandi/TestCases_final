# # # generator/generator.py

# import json
# import os
# import hashlib
# from pathlib import Path
# from langchain_community.chat_models import ChatOllama
# from langchain_core.prompts import ChatPromptTemplate
# from langgraph.graph import StateGraph, END
# from config import FORCE_REGENERATE


# # LLM (UNCHANGED)

# print("Loading model...")
# llm = ChatOllama(model="mistral", temperature=0.2, streaming=False)


# generator/generator.py - FIXED


#Last Working code


import json
import os
import hashlib
from pathlib import Path
from langchain_ollama import ChatOllama  # ✅ NEW IMPORT
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END
from config import FORCE_REGENERATE

print("Loading model...")
llm = ChatOllama(model="mistral", temperature=0.2)  # ✅ FIXED


# Utility Functions (UNCHANGED)
def load_json(path: Path):
    if path.exists():
        try:
            data = path.read_text(encoding="utf-8").strip()
            if not data:
                return {}
            return json.loads(data)
        except json.JSONDecodeError:
            print(f"Warning: {path} contains invalid JSON. Using empty dict instead.")
            return {}
    return {}

def save_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def compute_hash(data):
    return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

def load_hash(path: Path):
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return None

def save_hash(path: Path, hash_value):
    path.write_text(hash_value, encoding="utf-8")

def hepler(text):
    sections = {"Positive": [], "Negative": [], "Boundary": []}
    current = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("Positive"):
            current = "Positive"
        elif line.startswith("Negative"):
            current = "Negative"
        elif line.startswith("Boundary"):
            current = "Boundary"
        elif current and line:
            sections[current].append(line)
    return sections

# Graph State (UNCHANGED)
class State(dict):
    section: str
    text: str
    testcases: dict

# Generation Node (UNCHANGED)
def generate_testcases_node(state: State):
    print(f"Generating test cases for section: {state['section']}")
    prompt = ChatPromptTemplate.from_template("""
You are a Quality Assurance Engineer. Your task is to generate **comprehensive test cases** for the given requirements.

    Guidelines:

    1. Cover **positive**, **negative**, and **boundary/edge cases** wherever applicable.
    2. Keep sentences concise and self-contained.
    3. Do not skip unrelated generic test cases that may be required for security, risk, or permission checks.
    4. Do NOT include sections like "Test Steps", "Preconditions", or "Expected Result".
    6. Group test cases ONLY under the following three sections and in this exact order:
       Positive
       Negative
       Boundary
    
   
    7. Requirement type (Functional, business, technocal, security, data, non-functional) MUST NOT be used for grouping. All Testcases must be classified ONLY as positive, negative or boundary.                                  
                    

    for example :                                          
     Requirements: 
     Additional Driver Age Validation
     Restrictions in the NBL Application
        
    would generate below testcases:
    
    Positive
       Verify that the system allows creation of an additional driver when the entered age is 18 or above.
       Verify that clicking the Reset button allows the user to re-enter valid data.

    Negative
       Verify that the system blocks additional driver creation when the entered age is below 18.
       Verify that the system displays the error message "Applicant Age not in Range" when the entered age is below 18.

    Boundary
        Verify that the system allows additional driver creation when the entered age is exactly 18.
        Verify that the system blocks additional driver creation when the entered age is exactly 17.
    
    
    Requirement:
    {input_text}
""")
    chain = prompt | llm
    result = chain.invoke({"input_text": state["text"]})
    print("Testcases++++++++++++++++",result)
    state["testcases"][state["section"]] = result.content
    return state

# LangGraph (UNCHANGED)
graph = StateGraph(State)
graph.add_node("generate", generate_testcases_node)
graph.set_entry_point("generate")
graph.add_edge("generate", END)
app = graph.compile()

# PUBLIC ENTRY FUNCTION (NEW)
def run_generator(
    master_requirement_file: Path,
    new_requirement_file: Path | None,
    output_testcase_file: Path,
    hash_file: Path
):
    """
    Called by app.py or CLI
    """

    stored_requirements = load_json(master_requirement_file)
    new_requirements = load_json(new_requirement_file) if new_requirement_file else {}

    generate_master = not output_testcase_file.exists() or FORCE_REGENERATE
    generate_new = bool(new_requirements)

    if not generate_master and not generate_new:
        print("Nothing new to generate.")
        return

    all_testcases = {}

    # --- Master ---
    if generate_master:
        for section, requirements in stored_requirements.items():
            combined_text = "\n".join(requirements)
            result = app.invoke({
                "section": section,
                "text": combined_text,
                "testcases": all_testcases
            })
            all_testcases.update(result["testcases"])

    # --- Missing only ---
    if generate_new:
        for section, requirements in new_requirements.items():
            combined_text = "\n".join(requirements)
            result = app.invoke({
                "section": section,
                "text": combined_text,
                "testcases": all_testcases
            })
            all_testcases.update(result["testcases"])

            stored_requirements.setdefault(section, [])
            for req in requirements:
                if req not in stored_requirements[section]:
                    stored_requirements[section].append(req)

    merged = {"Positive": [], "Negative": [], "Boundary": []}
    for section_output in all_testcases.values():
        split = hepler(section_output)
        for k in merged:
            merged[k].extend(split[k])

    mode = "w" if generate_master else "a"
    with output_testcase_file.open(mode, encoding="utf-8") as f:
        for section in ["Positive", "Negative", "Boundary"]:
            f.write(f"{section}:\n")
            for i, tc in enumerate(merged[section], 1):
                f.write(f"{tc.lstrip('0123456789. ')}\n")
            f.write("\n")
    
    save_json(master_requirement_file, stored_requirements)
    save_hash(hash_file, compute_hash(stored_requirements))

    if new_requirement_file:
        save_json(new_requirement_file, {})

    print("Test cases generated successfully.")











# import json
# import os
# import hashlib
# import pandas as pd
# from pathlib import Path
# from langchain_community.chat_models import ChatOllama
# from langchain_core.prompts import ChatPromptTemplate
# from langgraph.graph import StateGraph, END
# import re
# from sentence_transformers import SentenceTransformer, util
# from config import FORCE_REGENERATE

# # LLM (UNCHANGED)
# print("Loading model...")
# llm = ChatOllama(model="mistral", temperature=0.2, streaming=False)

# # ===== NEW: PRIORITIZATION MODELS =====
# print("Loading prioritization models...")
# PRIORITY_MODEL = SentenceTransformer('all-MiniLM-L6-v2')
# priority_model = PRIORITY_MODEL

# # Utility Functions (UNCHANGED)
# def load_json(path: Path):
#     if path.exists():
#         try:
#             data = path.read_text(encoding="utf-8").strip()
#             if not data:
#                 return {}
#             return json.loads(data)
#         except json.JSONDecodeError:
#             print(f"Warning: {path} contains invalid JSON. Using empty dict instead.")
#             return {}
#     return {}

# def save_json(path: Path, data):
#     path.write_text(json.dumps(data, indent=2), encoding="utf-8")

# def compute_hash(data):
#     return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()

# def load_hash(path: Path):
#     if path.exists():
#         return path.read_text(encoding="utf-8").strip()
#     return None

# def save_hash(path: Path, hash_value):
#     path.write_text(hash_value, encoding="utf-8")

# def hepler(text):
#     sections = {"Positive": [], "Negative": [], "Boundary": []}
#     current = None
#     for line in text.splitlines():
#         line = line.strip()
#         if line.startswith("Positive"):
#             current = "Positive"
#         elif line.startswith("Negative"):
#             current = "Negative"
#         elif line.startswith("Boundary"):
#             current = "Boundary"
#         elif current and line:
#             sections[current].append(line)
#     return sections

# # ===== NEW: PRIORITIZATION FUNCTIONS =====
# def load_requirements_priority():
#     """Load requirements with priority scores"""
#     req_file = Path("high_accuracy_requirements.json")
#     if not req_file.exists():
#         print("⚠️  Requirements file not found, using default priorities")
#         return {}
    
#     data = load_json(req_file)
#     req_dict = {}
#     for req in data.get('requirements', []):
#         req_id = req.get('id', '')
#         req_dict[req_id] = {
#             'confidence': req.get('confidence', 0.5),
#             'ssd_context_score': req.get('ssd_context_score', 0.5),
#             'req_priority': req.get('req_priority', 0.5)
#         }
#     return req_dict

# def prioritize_testcases(merged_testcases):
#     """Prioritize test cases based on requirements"""
#     requirements = load_requirements_priority()
#     prioritized = []
    
#     # Parse each test case
#     all_tc_text = []
#     for section, tcs in merged_testcases.items():
#         for tc in tcs:
#             all_tc_text.append({
#                 'text': tc,
#                 'section': section,
#                 'raw': tc
#             })
    
#     # Calculate priority for each
#     for tc in all_tc_text:
#         text = tc['text'].lower()
        
#         # Extract requirement IDs
#         req_ids = re.findall(r'(\d+(?:\.\d+)*)', text)
        
#         # Requirement priority ( weight)
#         req_priority = 0.5
#         for req_id in req_ids:
#             if req_id in requirements:
#                 req_score = requirements[req_id].get('req_priority', 0.5)
#                 req_priority = max(req_priority, req_score)
        
#         # Risk keywords (30% weight)
#         risk_keywords = ['security', 'login', 'payment', 'error', 'auth', 'critical']
#         risk_score = 0.8 if any(kw in text for kw in risk_keywords) else 0.4
        
#         # Scenario balance (10% weight)
#         scenario_bonus = 0.9 if 'negative' in tc['section'].lower() or 'boundary' in tc['section'].lower() else 0.7
        
#         # Final priority score
#         priority_score = (req_priority * 0.6 + risk_score * 0.3 + scenario_bonus * 0.1)
        
#         tc['priority_score'] = priority_score
#         tc['priority_rank'] = 'HIGH' if priority_score > 0.7 else 'MEDIUM' if priority_score > 0.4 else 'LOW'
#         tc['linked_requirements'] = req_ids
#         prioritized.append(tc)
    
#     # Sort by priority (HIGH FIRST)
#     prioritized.sort(key=lambda x: x['priority_score'], reverse=True)
#     return prioritized

# # Graph State (UNCHANGED)
# class State(dict):
#     section: str
#     text: str
#     testcases: dict

# # Generation Node (UNCHANGED)
# def generate_testcases_node(state: State):
#     print(f"Generating test cases for section: {state['section']}")
#     prompt = ChatPromptTemplate.from_template("""
# You are a Quality Assurance Engineer. Your task is to generate **comprehensive test cases** for the given requirements.

#     Guidelines:

#     1. Cover **positive**, **negative**, and **boundary/edge cases** wherever applicable.
#     2. Keep sentences concise and self-contained.
#     3. Do not skip unrelated generic test cases that may be required for security, risk, or permission checks.
#     4. Do NOT include sections like "Test Steps", "Preconditions", or "Expected Result".
#     6. Group test cases ONLY under the following three sections and in this exact order:
#        Positive
#        Negative
#        Boundary
    
#     7. Requirement type (Functional, business, technocal, security, data, non-functional) MUST NOT be used for grouping. All Testcases must be classified ONLY as positive, negative or boundary.                  
                    
#     for example :                                                                          
#      Requirements: 
#      Additional Driver Age Validation
#      Restrictions in the NBL Application
       
#     would generate below testcases:
    
#     Positive
#        Verify that the system allows creation of an additional driver when the entered age is 18 or above.
#        Verify that clicking the Reset button allows the user to re-enter valid data.

#     Negative
#        Verify that the system blocks additional driver creation when the entered age is below 18.
#        Verify that the system displays the error message "Applicant Age not in Range" when the entered age is below 18.

#     Boundary
#         Verify that the system allows additional driver creation when the entered age is exactly 18.
#         Verify that the system blocks additional driver creation when the entered age is exactly 17.
    
#     Requirement:
#     {input_text}
# """)
#     chain = prompt | llm
#     result = chain.invoke({"input_text": state["text"]})
#     print("Testcases++++++++++++++++",result)
#     state["testcases"][state["section"]] = result.content
#     return state

# # LangGraph (UNCHANGED)
# graph = StateGraph(State)
# graph.add_node("generate", generate_testcases_node)
# graph.set_entry_point("generate")
# graph.add_edge("generate", END)
# app = graph.compile()

# # PUBLIC ENTRY FUNCTION (MODIFIED)
# def run_generator(
#     master_requirement_file: Path,
#     new_requirement_file: Path | None,
#     output_testcase_file: Path,
#     hash_file: Path
# ):
#     """
#     Called by app.py or CLI
#     """

#     stored_requirements = load_json(master_requirement_file)
#     new_requirements = load_json(new_requirement_file) if new_requirement_file else {}

#     generate_master = not output_testcase_file.exists() or FORCE_REGENERATE
#     generate_new = bool(new_requirements)

#     if not generate_master and not generate_new:
#         print("Nothing new to generate.")
#         return

#     all_testcases = {}

#     # --- Master ---
#     if generate_master:
#         for section, requirements in stored_requirements.items():
#             combined_text = "\n".join(requirements)
#             result = app.invoke({
#                 "section": section,
#                 "text": combined_text,
#                 "testcases": all_testcases
#             })
#             all_testcases.update(result["testcases"])

#     # --- Missing only ---
#     if generate_new:
#         for section, requirements in new_requirements.items():
#             combined_text = "\n".join(requirements)
#             result = app.invoke({
#                 "section": section,
#                 "text": combined_text,
#                 "testcases": all_testcases
#             })
#             all_testcases.update(result["testcases"])

#             stored_requirements.setdefault(section, [])
#             for req in requirements:
#                 if req not in stored_requirements[section]:
#                     stored_requirements[section].append(req)

#     # ===== ORIGINAL: Create merged testcases =====
#     merged = {"Positive": [], "Negative": [], "Boundary": []}
#     for section_output in all_testcases.values():
#         split = hepler(section_output)
#         for k in merged:
#             merged[k].extend(split[k])

#     # ===== NEW: PRIORITIZE TEST CASES =====
#     print("🎯 Prioritizing test cases...")
#     prioritized_testcases = prioritize_testcases(merged)
    
#     # ===== NEW: SAVE PRIORITIZED testcases.txt =====
#     with output_testcase_file.open("w", encoding="utf-8") as f:
#         f.write("🏆 PRIORITIZED TEST CASES (HIGH → LOW PRIORITY)\n")
#         f.write("=" * 60 + "\n\n")
        
#         for i, tc in enumerate(prioritized_testcases, 1):
#             rank_icon = "🔴" if tc['priority_rank'] == 'HIGH' else "🟡" if tc['priority_rank'] == 'MEDIUM' else "🟢"
#             f.write(f"{i:2d}. {rank_icon} [{tc['priority_rank']}] {tc['priority_score']:.2f}\n")
#             f.write(f"   {tc['text']}\n")
#             if tc['linked_requirements']:
#                 f.write(f"   📋 Covers: {', '.join(tc['linked_requirements'])}\n")
#             f.write("\n")
    
#     # ===== NEW: ALSO SAVE JSON for validator =====
#     prioritized_json = {
#         'prioritization_date': pd.Timestamp.now().isoformat(),
#         'total_testcases': len(prioritized_testcases),
#         'high_priority': len([tc for tc in prioritized_testcases if tc['priority_rank'] == 'HIGH']),
#         'testcases': prioritized_testcases
#     }
#     prioritized_json_path = output_testcase_file.with_suffix('.json')
#     save_json(prioritized_json_path, prioritized_json)
    
#     save_json(master_requirement_file, stored_requirements)
#     save_hash(hash_file, compute_hash(stored_requirements))

#     if new_requirement_file:
#         save_json(new_requirement_file, {})

#     print("✅ Test cases generated AND PRIORITIZED successfully!")
#     print(f"📄 Saved: {output_testcase_file}")
#     print(f"💾 JSON: {prioritized_json_path}")
#     print(f"🏆 HIGH: {prioritized_json['high_priority']}/{prioritized_json['total_testcases']}")

# # ===== NEW: pandas import for timestamp =====

